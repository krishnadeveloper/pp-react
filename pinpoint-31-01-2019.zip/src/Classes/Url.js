class Url {
    constructor()
    {
        this.url = window;
    }

    getHost()
    {
        return this.url.location.hostname;
    }

    getProtocol()
    {
        return this.url.location.protocol;
    }

    getPort()
    {
        return this.url.location.port;
    }

    getPath()
    {
        return this.url.location.pathname;
    }

    /**
     * 
     * @param {*} extendUrl : you can pass the url to extend with base url
     */
    baseUrl(extendUrl=''){
        var completeURL = this.url.location.protocol+'//'+this.url.location.hostname;
        completeURL = completeURL+(this.url.location.port>0?':'+this.url.location.port+'/':'/');
        completeURL = completeURL+(extendUrl.length>0?extendUrl+'/':'');
        return completeURL;
    }
    /**
     * Get current url like https://yourdomain.com/user/profile
     */
    currenUrl(){
        //console.log(this.url.location.pathname);
        var completeURL = this.url.location.protocol+'//'+this.url.location.hostname;
        completeURL = completeURL+(this.url.location.port>0?':'+this.url.location.port+'':'/');
        completeURL = completeURL+(this.url.location.pathnam!==''?this.url.location.pathname+'/':'');
        return completeURL;
    }

    getParam(){
        console.log(this.url);
    }

    httpBuildQuery(object)
    {
        return Object.keys(object).map((key)=>{return(key+'='+object[key])}).join('&');
    }

    moveToTop(){
        
        window.scrollTo(0, 0);
    }

    createSlug(text)
    {
        return text.replace(/[^A-Za-z0-9-]+/g, '-').toLowerCase();
    }

}

export default new Url(); 