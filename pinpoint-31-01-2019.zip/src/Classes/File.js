class File 
{
    /**
     * 
     * @param {*} url : any url of file name
     */

    nameFromUrl(url)
    {
        let name = url.substring(url.lastIndexOf('/')+1);
        //console.log(name);
        return name;
    }
}

export default new File();