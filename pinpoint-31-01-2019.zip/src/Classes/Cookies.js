class Cookie {
    set(cname,cvalue,exdays
        ){
        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    getCookie(cname){
        var cname = cname;
        var cookies = document.cookie.split(";");
        //console.log(cookies);
        for(i=0; i<cookies.length; i++){
            //var exString = cookies[i].split('')
            if(indexOf(cookies[i])==0){
                
            }
        }
    }

    getAllCookie(){
        return document.cookie.split(";");
    }
}


export default new Cookie();