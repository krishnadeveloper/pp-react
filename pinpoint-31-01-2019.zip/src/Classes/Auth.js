import Storage from "./Storage";
import constantKey from "../Config/ConstantKey";

class Auth 
{
    /**
     * isLogin function is return boolean value 
     */
    isLogin()
    {
        return (Storage.getBool(constantKey.login) === 'true' || Storage.getBool(constantKey.login) === true)?true:false;
    }

    /**
     * showMyorder function return boolean value 
     */
    showMyorder()
    {
       return (Storage.getBool(constantKey.myorder) === 'true' || Storage.getBool(constantKey.myorder) === true)?true:false;
    }
}

export default new Auth();