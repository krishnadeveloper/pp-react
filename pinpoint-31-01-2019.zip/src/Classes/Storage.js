import Encryption from "./Encryption";
class Storage extends Encryption {
    /**
     * 
     * @param {*} key : pass any key 
     * @param {*} val : value in respective to key
     */
    set(key,val)
    {
        localStorage.setItem(key,this.encode(val));
    }
    /**
     * 
     * @param {*} key : Pass key to fetch value
     */
    get(key)
    {   
        if(localStorage.getItem(key)===null)
        {
            return false;
        }
        return this.decode(localStorage.getItem(key));
    }
    /**
     * 
     * @param {*} key : Pass key to fetch boolien value
     */
    getBool(key)
    {
        return localStorage.getItem(key);
    }

    /**
     * 
     * @param {*} key : Pass key to remove
     */
    remove(key)
    {
        localStorage.removeItem(key)
    }
}

export default new Storage();