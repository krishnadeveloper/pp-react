class Checkbox 
{
    constructor()
    {
        this.checkbox = {
            allchecked:[]
        }
    }


    /**
     * 
     * @param {*} name : Pass the name of checkbox element to get the value of all checked checkbox value
     */
    getChecked(name)
    {
        let allCheckbox = document.getElementsByName(name);
        let allChecked = [];
        for (let index = 0; index < allCheckbox.length; index++) {
            if(allCheckbox[index].checked)
            {
                allChecked.push(allCheckbox[index].parentElement.textContent);
            }
        }

        this.checkbox.allchecked = allChecked;
        return allChecked;

    }

    getCheckedFilter(name,filter)
    {
        let allCheckbox = document.getElementsByName(name);
        let allChecked = [];
        for (let index = 0; index < allCheckbox.length; index++) {
            if(allCheckbox[index].checked)
            {   
                filter? allChecked.push(this.filterLeadtime(allCheckbox[index].parentElement.textContent)) : allChecked.push(allCheckbox[index].parentElement.textContent)
            }
        }

        this.checkbox.allchecked = allChecked;
        return allChecked;

    }


    filterLeadtime(value){
        return value.replace(/([^0-9-]+)/gi, '');
    }

    concatBy(separator)
    {
        return this.checkbox.allchecked.join(separator);
    }
}

export default new Checkbox();