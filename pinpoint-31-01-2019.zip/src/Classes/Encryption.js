import CryptoJS from "crypto-js";
const encKey= 'PinCr(^)628';
const conf = {};
class Encryption {
    // encode function will encrypt the string
    encode(string){
        // @string to encrypt
        return CryptoJS.AES.encrypt(string.toString(),encKey,conf);
    }

    // decode function will decrypt the encrypted string
    decode(ciphertext){
        // @ciphertext to decrypt the encrypted string
        const bytes  = CryptoJS.AES.decrypt(ciphertext.toString(), encKey);
        return bytes.toString(CryptoJS.enc.Utf8);
    }
}

export default Encryption;