import React from 'react';
import ProductModel from "../../Model/Product";
import Auth from "../../Classes/Auth";
import htmlParser from "react-html-parser";
import File from "../../Classes/File";
import {NavLink} from "react-router-dom";

require('./css/product.css');

function fPrice (v, d) {
    if (d) v = v.toFixed(d).replace(/(\.[0-9]{2})0*/, '$1');
    return '£' + v;
}

Array.prototype.equals = function (array) {
    if (!array) return false;
    if (this.length !== array.length) return false;
    for (var i = 0, l = this.length; i < l; i++) {
        if (this[i] instanceof Array && array[i] instanceof Array) {
            if (!this[i].equals(array[i])) return false;       
        }           
        else if (this[i] !== array[i]) { 
            return false;   
        }           
    }       
    return true;
}
Object.defineProperty(Array.prototype, "equals", {enumerable: false});


Object.defineProperty(Array.prototype,'chunk',{
    value:function (chunkSize) {
        var that = this;
        return Array(Math.ceil(that.length/chunkSize)).fill().map(function(_,i){
            return that.slice(i*chunkSize,i*chunkSize+chunkSize);
        })
    }
})


class Product extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            activeTab: 'description',
            productRef:props.match.params.reference,
            product:'',
            loading:true,
            noProduct:false,
            pricesHTML:'',
            pricesHTMLafter:'',
            pricesAllHTML:'',
            pricesAllHTMLafter:''

        }
        
        this.makeTabActive = this.makeTabActive.bind(this);

    }

    componentWillMount()
    {
        //console.log(this.state.productRef+'132');
        ProductModel.find(this.props.match.params.reference).then(res=>{
            
            // If res.data.product = object => product found
            console.log(res.data);
            if(typeof(res.data.product)==='object'){

                console.log('Product Found')
                //console.log(res.data.product.prices)

                //if (res.data.product['images-local']) res.data.product['images'] = res.data.product['images-local'];
                // else if (res.data.product['images']) {
                //     saveImages(res.data.product['images'], res.data.product.id);
                // }
                //else if (res.data.product['img-local-l']) res.data.product['images'] = [res.data.product['img-local-l']];
                //else if (res.data.product['img']) res.data.product['images'] = [res.data.product['img'] + '/l'];

                // if (res.data.product['images-local']) res.data.product['images'] = res.data.product['images-local'];
                // else if (res.data.product['img-local-l']) res.data.product['images'] = [res.data.product['img-local-l']];
                // else if (res.data.product['img']) res.data.product['images'] = [res.data.product['img'] + '/l'];
                // else if (res.data.product['images']) {
                //     saveImages(res.data.product['images'], res.data.product.id);
                // }
                var pricesHTML = '';
                var pricesHTMLafter = '';
                var pricesAllHTML = '';
                var pricesAllHTMLafter = '';
                var extraCol = false;
                var prevType = false;

                if (res.data.product.hasOwnProperty('prices')) {
                    //console.log(res.data.product.prices)
                    for (let type in Object.keys(res.data.product.prices)) {
                        type = Object.keys(res.data.product.prices)[type];
                        var thisType = res.data.product.prices[type];
                        thisType.main = thisType.main !== undefined ? thisType.main : '';
                        //console.log('prevType +=' + prevType.main + ', thisType+=' + thisType.main);
                        // if first type, or quantity/extras/setup/carriage doesn't match, new table + header + prep footer
                        if (!prevType || !Object.keys(prevType.main).equals(Object.keys(thisType.main)) || JSON.stringify(prevType.extras) !== JSON.stringify(thisType.extras) || JSON.stringify(prevType.setup) !== JSON.stringify(thisType.setup) || JSON.stringify(prevType.carriage) !== JSON.stringify(thisType.carriage)) {
                            if (prevType) {
                                pricesHTML += pricesHTMLafter + '</table>';
                                pricesHTMLafter = '';
                                extraCol = false;
                            }

                            pricesHTML += '<table className="table"><tr><td className="bg-dg"></td>';
                            // if any row extras has setup, extraColumn = true;
                            if (thisType.extras) {
                                for (let extra in Object.keys(thisType.extras)) {
                                    extra = Object.keys(thisType.extras)[extra];
                                    if (Number(thisType.extras[extra].setup) > 0) extraCol = true
                                }
                            }

                            for (let quan in Object.keys(thisType.main)) {
                                quan = parseInt(Object.keys(thisType.main)[quan], 10); // header row with quans
                                pricesHTML += '<td className="bg-dg">' + quan.toLocaleString() + '</td>';
                            }

                            pricesHTML += (extraCol ? '<tr><td className="bg-lg">Setup</td>' : '') + '</tr>';
                            // setup row for type, save to AFTER - use when new table or at end
                            pricesHTMLafter += '<tr className="pr-foot"><td className="pr-foot-cell">Setup</td>';
                            for (let price in thisType.setup) {
                                price = thisType.setup[price];
                                pricesHTMLafter += '<td className="pr-foot-cell">' + (Number(price) === 0 ? 'FOC' : (Number(price) === 999 ? 'n/a' : fPrice(price))) + '</td>';
                            }
                            pricesHTMLafter += (extraCol ? '<td className="pr-foot-cell">&nbsp;</td>' : '') + '</tr>';

                            // extras rows, save to AFTER - use when new table or at end
                            if (thisType.extras) {
                                for (let extra in Object.keys(thisType.extras)) {
                                    extra = Object.keys(thisType.extras)[extra];
                                    pricesHTMLafter += '<tr className="pr-foot"><td className="pr-foot-cell" title="' + extra + '">' + extra + '</td>';
                                    for (let price in thisType.extras[extra].main) {
                                        price = thisType.extras[extra].main[price]
                                        pricesHTMLafter += '<td className="pr-foot-cell">' + (Number(price) === 0 ? 'FOC' : (Number(price) === 999 ? 'n/a' : fPrice(price))) + '</td>';
                                    }
                                    if (extraCol) {
                                        pricesHTMLafter += '<td className="pr-foot-cell">' + (Number(thisType.extras[extra].setup) === 0 ? 'FOC' : fPrice(thisType.extras[extra].setup)) + '</td>';
                                    }
                                    pricesHTMLafter += '</td>';
                                }
                            }

                            // carriage row for type, save to AFTER - use when new table or at end
                            pricesHTMLafter += '<tr className="pr-foot"><td className="pr-foot-cell">Carriage</td>';
                            for (let price in thisType.carriage) {
                                price = thisType.carriage[price];
                                pricesHTMLafter += '<td className="pr-foot-cell">' + (Number(price) === 0 ? 'FOC' : (Number(price) === 999 ? 'n/a' : fPrice(price))) + '</td>';
                            }
                            pricesHTMLafter += (extraCol ? '<td className="pr-foot-cell">&nbsp;</td>' : '') + '</td>';
                        }

                        // if first type, or quantity/extras doesn't match, new table + header + prep footer (all-in prices so setup/carriage match not required)
                        if (!prevType || !Object.keys(prevType.main).equals(Object.keys(thisType.main)) || JSON.stringify(prevType.extras) !== JSON.stringify(thisType.extras)) {
                            if (prevType) {
                                pricesAllHTML += pricesAllHTMLafter + '</table>';
                                pricesAllHTMLafter = '';
                                extraCol = false;
                            }

                            pricesAllHTML += '<table className="table"><tr className="pr-head"><td className="bg-dg"></td>';

                            // if any row extras has setup, extraColumn = true;
                            if (thisType.extras) {
                                for (let extra in Object.keys(thisType.extras)) {
                                    extra = Object.keys(thisType.extras)[extra];
                                    if (Number(thisType.extras[extra].setup) > 0) extraCol = true
                                }
                            }

                            for (let quan in Object.keys(thisType.main)) {
                                quan = parseInt(Object.keys(thisType.main)[quan], 10);
                                pricesAllHTML += '<td className="bg-dg">' + quan.toLocaleString() + '</td>';
                            }
                            pricesAllHTML += (extraCol ? '<td className="bg-dg">Setup</td>' : '') + '</td>';

                            // extras rows, save to AFTER - use when new table or at end
                            if (thisType.extras) {
                                for (let extra in Object.keys(thisType.extras)) {
                                    extra = Object.keys(thisType.extras)[extra];
                                    pricesAllHTMLafter += '<tr className="pr-foot"><td className="pr-foot-cell" title="' + extra + '">' + extra + '</td>';
                                    for (let price in thisType.extras[extra].main) {
                                        price = thisType.extras[extra].main[price]
                                        pricesAllHTMLafter += '<td className="pr-foot-cell">' + (Number(price) === 0 ? 'FOC' : fPrice(price)) + '</td>';
                                    }
                                    if (extraCol) {
                                        pricesAllHTMLafter += '<td className="pr-foot-cell">' + (Number(thisType.extras[extra].setup) === 0 ? 'FOC' : fPrice(thisType.extras[extra].setup)) + '</td>';
                                    }
                                    pricesAllHTMLafter += '</tr>';
                                }
                            }
                        }

                        // prices row for this type
                        pricesHTML += '<tr className="pr-row"><td className="pr-row-cell">' + type + '</td>';
                        pricesAllHTML += '<tr className="pr-row"><td className="pr-row-cell">' + type + '</td>';
                        for (let quan in Object.keys(thisType.main)) {
                            var i = quan;
                            quan = Object.keys(thisType.main)[quan];
                            pricesHTML += '<td className="pr-row-cell">' + fPrice(thisType.main[quan]) + '</td>';
                            pricesAllHTML += '<td className="pr-row-cell">' + fPrice(Number(thisType.main[quan]) + Number(thisType.setup[i] / quan) + Number(thisType.carriage[i] / quan), 3) + '</td>';
                        }
                        pricesHTML += '</tr>';
                        pricesAllHTML += '</tr>';

                        prevType = thisType;
                    }
                    pricesHTML += pricesHTMLafter + '</table>';
                    pricesAllHTML += pricesAllHTMLafter + '</table>';
                    res.data.product.pricesHTML = pricesHTML;
                    res.data.product.pricesAllHTML = pricesAllHTML;

                    if (res.data.product.extra) {
                        for (i in res.data.product.extra) {
                            res.data.product.extra[i].unit = res.data.product.extra[i]["unit-type"] === '%' ? res.data.product.extra[i].unit + '%' : fPrice(res.data.product.extra[i].unit);
                            res.data.product.extra[i].setup = res.data.product.extra[i]["setup-type"] === '%' ? res.data.product.extra[i].setup + '%' : fPrice(res.data.product.extra[i].setup);
                        }
                    }

                }
                //console.log(pricesHTML);

                this.setState(prevState=>{
                    return{
                        activeTab:'description',
                        loading:false,
                        product:res.data.product,
                        noProduct:true,
                        pricesHTML:pricesHTML,
                        pricesHTMLafter:pricesHTMLafter,
                        pricesAllHTML:pricesAllHTML,
                        pricesAllHTMLafter:pricesAllHTMLafter

                    }
                })
            }
            else{
                this.setState(prevState=>{
                    return{
                        activeTab:'description',
                        loading:false,
                        product:res.data.product,
                        noProduct:true,
                        pricesHTML:'',
                        pricesHTMLafter:'',
                        pricesAllHTML:'',
                        pricesAllHTMLafter:''
                    }
                })
            }
        })
    }

    componentDidMount(){
        var height = document.getElementById('eq-height-get').clientHeight-90;
        document.getElementById('dive').style.height = `${height}px`;
        setTimeout(()=>{
            console.log(this.state);
        },5000)
    }
    
    makeTabActive = (tab) => {
        this.setState(prevState => {
            return {
                activeTab: tab
            }
        })
    }



    render() {
        return (
            <div className="main-content product-screen">
                <div className="container product-content">
                    <h2 className="product-title">{this.state.product.name}</h2>
                    <div className="row">
                        <div className="col-sm-5" id="eq-height-get">
                            <div className="product-image">
                                {
                                    (this.state.product.hasOwnProperty('images') && this.state.product.images.length>0)
                                    ?
                                    <img src={this.state.product.images.length>0?this.state.product.images[0]:'/public/img/logo-g.svg'} className="img-responsive" alt="pinpoint" />
                                    :
                                    <img src='/public/img/logo-g.svg' className="img-responsive" alt="pinpoint" />
                                }
                        
                            </div>
                            {/* <ul className="product-thumbs">
                        <li className="thumb"><img src="img/silicon-straw.jpg" className="img-responsive" alt="pinpoint" /></li>
                        <li className="thumb"><img src="img/silicon-straw.jpg" className="img-responsive" alt="pinpoint" /></li>
                        <li className="thumb"><img src="img/silicon-straw.jpg" className="img-responsive" alt="pinpoint" /></li>
                    </ul>  */}
                            <div className="popup-container">
								<input id="popup-toggle" type="checkbox" />
								<label className="popup-btn btn btn-default btn-orng btn-block btn-round" for="popup-toggle">Request a sample</label>
								<label className="popup-backdrop" for="popup-toggle"></label>
								<div className="popup-content">
									<label className="popup-close" for="popup-toggle">&#x2715;</label>
									<h3>Request a Sample</h3>
									<hr />
									
										<div className="form-group">
											<label for="address">Home Address</label>
											<textarea className="form-control" id="address" name="homeaddress" rows="3" required ></textarea>
										</div>
										<div className="form-group">
											<label for="notes">Notes (optional)</label>
											<textarea className="form-control" id="notes" rows="3"></textarea>
										</div>
										<button type="submit" className="btn btn-default btn-orng">Submit</button>
									
								</div>
							</div>
                        </div>
                        <div className="col-sm-7">
                            <div className="product-details">
                                <ul className="nav nav-tabs" role="tablist">
                                    <li role="presentation" className={this.state.activeTab === 'description' ? 'active' : ''}><button href={()=>{}} onClick={()=>this.makeTabActive('description')} aria-controls="description" role="tab" data-toggle="tab"><i className="far fa-align-left"></i><span>Description</span></button></li>
                                    <li role="presentation" className={this.state.activeTab === 'product-spec' ? 'active' : ''}><button href={()=>{}} onClick={()=>this.makeTabActive('product-spec')} aria-controls="product-spec" role="tab" data-toggle="tab"><i className="far fa-info-circle"></i><span>Product Specs</span></button></li>
                                    <li role="presentation" className={this.state.activeTab === 'product-color' ? 'active' : ''}><button href={()=>{}} onClick={()=>this.makeTabActive('product-color')} aria-controls="product-spec" role="tab" data-toggle="tab"><i className="far fa-paint-brush"></i><span>Product Colour</span></button></li>
                                    <li role="presentation" className={this.state.activeTab === 'prices' ? 'active' : ''}><button href={()=>{}} onClick={()=>this.makeTabActive('prices')} aria-controls="prices" role="tab" data-toggle="tab"><i className="far fa-pound-sign"></i><span>Prices</span></button></li>
                                    <li role="presentation" className={this.state.activeTab === 'artwork' ? 'active' : ''}><button href={()=>{}} onClick={()=>this.makeTabActive('artwork')} aria-controls="artwork" role="tab" data-toggle="tab"><i className="far fa-image"></i><span>Artwork</span></button></li>
                                </ul>
                                <div className="tab-content eq-height-to" id="dive">
                                    <div role="tabpanel" className={this.state.activeTab==='description'?'tab-pane description active':"tab-pane description"} id="description">
                                        <h4 className="sub-title">Key features</h4>
                                        <ul className="icons">
                                            <li className="icon"><i className="fal fa-fill-drip"></i><p>Pantone Matched</p></li>
                                            <li className="icon"><i className="fal fa-fill-drip"></i><p>Eco friendly</p></li>
                                            <li className="icon"><i className="fal fa-fill-drip"></i><p>Top Seller</p></li>
                                        </ul>
                                        <div className="clearfix"></div>
                                        <div className="space-30"></div>
                                        <h4 className="sub-title">Product Description</h4>
                                        {htmlParser(this.state.product.description)}
                                    </div>
                                    <div role="tabpanel" className={this.state.activeTab==='product-spec'?'tab-pane product-spec active':"tab-pane product-spec"} id="product-spec">
                                        <table className="table">
                                            <tbody>
                                                {
                                                    this.state.product.spec ?
                                                        this.state.product.spec.length > 0
                                                            ?
                                                            this.state.product.spec.map(spec => {
                                                                return (
                                                                    <tr key={Math.random()}>
                                                                        <td>{spec.name}</td>
                                                                        <td>{spec.value}</td>
                                                                    </tr>
                                                                )

                                                            })
                                                            :
                                                            <tr>
                                                                <td colSpan="2">No specs found</td>
                                                            </tr>
                                                        :
                                                        ''
                                                }
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div role="tabpanel" className={this.state.activeTab==='product-color'?'tab-pane colors active':"tab-pane colors"} id="colors">
                                        {
                                            this.state.product.colors
                                            ?
                                                this.state.product.colors
                                                ?
                                                    Object.keys(this.state.product.colors).map((key)=>{
                                                        return(
                                                            <ul className="list-inline" key={Math.random()}>
                                                                <li className="color" color={key}>
                                                                    <div className="heading">{this.state.product.colors[key]}</div>
                                                                    <div className="swatch"></div>
                                                                </li>
                                                                {/* <span>{this.state.product.colors[key]}</span><br/>
                                                                <span style={{backgroundColor:key.substr(0,2)==='c~'?`#${key.substr(0,2)}`:key.substr(0,1)==='#'?key:key}}>{key}</span>
                                                                <br/><br/> */}
                                                            </ul>
                                                        )
                                                    })
                                                :    
                                                    ''
                                            :
                                            ''
                                        }
                                        
                                    </div>
                                    
                                    <div role="tabpanel" className={this.state.activeTab==='prices'?'tab-pane prices active':"tab-pane prices"} id="prices">
                                        {
                                            Auth.isLogin()
                                            ?<React.Fragment>
                                                <div className="alert alert-success fade in" role="alert">
                                                    <i className="fal fa-check-circle"></i> You are successfully logged in
                                                </div>
                                            </React.Fragment>
                                            :<React.Fragment>
                                                <h4>You must be logged in to view our prices</h4>
                                                <div className="buttons">
                                                    <a href={()=>{}} className="btn btn-orng btn-default">Login</a>
                                                    <a href={()=>{}} className="btn btn-blue btn-default">Apply for an account</a>
                                                </div>
                                            </React.Fragment>
                                        }
                                        
                                        <div className="space-20"></div>
                                        <h4>View prices below</h4>

                                        {/* <div className="table-responsive">

                                            <table className="table">
                                                <tbody>
                                                    <tr>
                                                        <td></td>
                                                        <td><span className="bg">500</span></td>
                                                        <td><span className="bg">1,000</span></td>
                                                        <td><span className="bg">2,500</span></td>
                                                        <td><span className="bg">5,000</span></td>
                                                    </tr>
                                                    <tr>
                                                        <td>7mm diameter</td>
                                                        <td>£0.55</td>
                                                        <td>£0.52</td>
                                                        <td>£0.49</td>
                                                        <td>£0.44</td>
                                                    </tr>
                                                    <tr>
                                                        <td className="border"></td>
                                                        <td colspan="4" className="border"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>11.5mm diameter</td>
                                                        <td>£0.55</td>
                                                        <td>£0.52</td>
                                                        <td>£0.49</td>
                                                        <td>£0.44</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Setup</td>
                                                        <td>£0.55</td>
                                                        <td>£0.52</td>
                                                        <td>£0.49</td>
                                                        <td>£0.44</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Carriage</td>
                                                        <td>£0.55</td>
                                                        <td>£0.52</td>
                                                        <td>£0.49</td>
                                                        <td>£0.44</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5"></td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="5"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Extras</strong></td>
                                                        <td><span className="bg">Unit</span></td>
                                                        <td><span className="bg">Setup</span></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Cleaning Brush</td>
                                                        <td>£0.15</td>
                                                        <td>£0</td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div> */}
                                    </div>
                                    <div role="tabpanel" className={this.state.activeTab==='artwork'?'tab-pane artwork active':"tab-pane artwork"} id="artwork">
                                        {
                                            this.state.product.hasOwnProperty('downloads')
                                            ?
                                                this.state.product.downloads.length>0
                                                ?
                                                    this.state.product.downloads.map(download=>{

                                                        return(
                                                                <a href={download} download={download} className="btn btn-orng">
                                                                    {
                                                                        File.nameFromUrl(download)
                                                                    }
                                                                    <i className="fas fa-download" />
                                                                </a>
                                                        )

                                                    })
                                                :
                                                    ''

                                            :
                                                ''
                                        }
                                        {
                                            this.state.product.hasOwnProperty('templates')
                                            ?
                                                this.state.product.templates.length>0
                                                ?
                                                    this.state.product.templates.map(template=>{

                                                        return(
                                                                <a href={template} download={template} className="btn btn-orng">
                                                                    {
                                                                        File.nameFromUrl(template)
                                                                    }
                                                                    <i className="fas fa-download" />
                                                                </a>
                                                        )

                                                    })
                                                :
                                                    ''

                                            :
                                                ''
                                        }

                                        {
                                            !Auth.isLogin() 
                                                ?
                                                <React.Fragment>
                                                    <h4 className="">You must be logged in to view artwork</h4>
                                                    <div className="buttons ">
                                                        <a href="/index.php/auth/login" className="btn btn-orng btn-default">Login</a>
                                                        <NavLink to="/apply-to-login" className="btn btn-blue btn-default">Apply for an account</NavLink>
                                                    </div>
                                                    <div className="space-20"></div>
                                                </React.Fragment>
                                                : 
                                                ''
                                        }

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="clearfix"></div>
                <div className="product-price-table container">
                    <h3 className="title">{this.state.product.name}</h3>
                    <div className="table-responsive">
                            {
                                Auth.isLogin()
                                ?
                                htmlParser(this.state.pricesHTML)
                                :<React.Fragment>
                                    <h4 className="text-center">You must be logged in to view our prices</h4>
                                    <div className="buttons text-center">
                                        <a href="/index.php/auth/login" className="btn btn-orng btn-default">Login</a>
                                        <NavLink to="/apply-to-login" className="btn btn-blue btn-default">Apply for an account</NavLink>
                                    </div>
                                    <div className="space-20"></div>
                                </React.Fragment>
                            }

                        {
                             // Price table after content
                            //htmlParser(this.state.pricesHTMLafter)
                        }

                        {
                            // All Prices
                            //htmlParser(this.state.pricesAllHTML)
                        }

                        {
                            // All Prices after content
                            //htmlParser(this.state.pricesAllHTMLafter)
                        }
                        {
                            this.state.product.hasOwnProperty('extra')
                            ?
                                this.state.product.extra.length>0
                                ?
                                    <table className="table">
                                        
                                        <tr>
                                            <td><strong>Extras</strong></td>
                                            <td className="bg-dg">Unit</td>
                                            <td className="bg-dg">Setup</td>
                                            {
                                                this.state.product.extra.length>6
                                                ?
                                                <React.Fragment>
                                                    <td><strong>Extras</strong></td>
                                                    <td className="bg-dg">Unit</td>
                                                    <td className="bg-dg">Setup</td>
                                                </React.Fragment>
                                                :
                                                ''
                                            }
                                            

                                        </tr>
                                        {
                                            this.state.product.extra.length>6
                                            ?
                                                this.state.product.extra.chunk(2).map(extraArr=>{
                                                    return (

                                                        <tr>
                                                            {
                                                                extraArr.map(ext => {
                                                                    return(
                                                                        <React.Fragment>
                                                                            <td>{ext.name}</td>
                                                                            <td>{ext.unit}</td>
                                                                            <td>{ext.setup}</td>
                                                                        </React.Fragment>
                                                                    )
                                                                })

                                                            }

                                                        </tr>
                                                    )
                                                })
                                            :
                                                this.state.product.extra.map(extra=>{
                                                    return(
                                                        <React.Fragment>
                                                            <tr>
                                                                <td>{extra.name}</td>
                                                                <td>{extra.unit}</td>
                                                                <td>{extra.setup}</td>
                                                            </tr>
                                                        </React.Fragment> 
                                                    )
                                                })
                                        }
                                        
                                    </table>
                                :      
                                    ''
                            :
                            ''
                        }
                        
                    </div>
                </div>
                <div className="clearfix"></div>
                <div className="space-50"></div>
                {/* <div className="similar-products">
            <div className="container">
                <h2 className="title">You might also like</h2>
                <div className="row">
                    <div className="col-sm-6 col-md-3">
                        <a href={()=>{}}>
                            <div className="product-panel">
                                <div className="p-img">
                                    <img alt="pinpoint" src="img/p1.jpg" className="img-responsive" />
                                </div>
                                <div className="p-title">Soft Enamel Badges</div>
                            </div>
                        </a>
                    </div>
                    <div className="col-sm-6 col-md-3">
                        <a href={()=>{}}>
                            <div className="product-panel">
                                <div className="p-img">
                                    <img alt="pinpoint" src="img/p2.jpg" className="img-responsive" />
                                </div>
                                <div className="p-title">Flat Ribbed Lanyards</div>
                            </div>
                        </a>
                    </div>
                    <div className="col-sm-6 col-md-3">
                        <a href={()=>{}}>
                            <div className="product-panel">
                                <div className="p-img">
                                    <img alt="pinpoint" src="img/p3.jpg" className="img-responsive" />
                                </div>
                                <div className="p-title">Enamel Trolley Coins</div>
                            </div>
                        </a>
                    </div>
                    <div className="col-sm-6 col-md-3">
                        <a href={()=>{}}>
                            <div className="product-panel">
                                <div className="p-img">
                                    <img alt="pinpoint" src="img/p4.jpg" className="img-responsive" />
                                </div>
                                <div className="p-title">Powerlink Multi-Cable</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div> */}
            </div>
        );
    }
};

export default Product;