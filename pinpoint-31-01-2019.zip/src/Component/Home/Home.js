import React from 'react';
import Banner from "./Banner";
import Strip from "./Strip";
import "./css/home.css";
import ProductCategory from './ProductCategory';
import PopularProduct from './PopularProduct';
import NewProduct from "./NewProduct";
import Whyus from './Whyus';


const Home = () => {
    return (
        <React.Fragment>
            <Banner/>
            <Strip/>
            <ProductCategory/>
            <PopularProduct/>
            <NewProduct/>
            <Whyus/>
        </React.Fragment>
    );
};

export default Home;