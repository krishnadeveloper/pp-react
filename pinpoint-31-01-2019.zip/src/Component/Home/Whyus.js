import React from 'react';
import {NavLink} from "react-router-dom";

const Whyus = () => {
    return (
        <div className="hm-why">
			<div className="container">
				<h2 className="title">Why Choose us?</h2>
				<div className="row">
					<div className="col-sm-6 col-md-3">
						<div className="icon">
							<i className="fal fa-calendar-alt"></i>
						</div>
						<h3>Since 1980</h3>
						<p>Pinpoint has been an established key supplier to the industry for more than 39 years, bringing a wealth of experience to our customers.</p>
					</div>
					<div className="col-sm-6 col-md-3">
						<div className="icon">
							<i className="fal fa-user-alt"></i>
						</div>
						<h3>Dedicated Manager</h3>
						<p>Each customer is assigned a dedicated account manager to make each enquiry as seamless as possible.</p>
					</div>
					<div className="col-sm-6 col-md-3">
						<div className="icon">
							<i className="fal fa-building"></i>
						</div>
						<h3>Office in China</h3>
						<p>With the rapid growth in product sourcing, we now have an office in China to ensure the quality of orders and staying up to date with the latest trends.</p>
					</div>
					<div className="col-sm-6 col-md-3">
						<div className="icon">
							<i className="fal fa-truck"></i>
						</div>
						<h3>Fast Delivery</h3>
						<p>Using the latest production techniques we are able to offer express services on our core range and all UK manufactured products.</p>
					</div>
				</div>
				<div className="clearfix"></div>
				<NavLink className="btn btn-default btn-orng" to="/about">Read more about us</NavLink>
			</div>
		</div>
    );
};

export default Whyus;