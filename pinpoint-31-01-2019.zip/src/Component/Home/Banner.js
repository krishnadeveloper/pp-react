import React from 'react';
import {NavLink} from "react-router-dom";

const Banner = () => {
    return (
        <div class="slider">
            <div id="slider" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <img src="/assets/img/banner.jpg" alt="pinpoint" class="img-responsive" />
                        <div class="carousel-caption">
                            {/* <h1>Promotional Products</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> */}
                            <NavLink to='/product/all' class="btn btn-orng btn-default btn-md">Browse our Products</NavLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            );
        };
        
export default Banner;