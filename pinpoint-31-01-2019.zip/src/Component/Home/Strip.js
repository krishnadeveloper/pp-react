import React from 'react';

const Strip = () => {
    return (
        <div class="banner-featured">
			<div class="container">
				<h1 class="title">Brand Specialists Since 1980</h1>
			</div>
		</div>
    );
};

export default Strip;