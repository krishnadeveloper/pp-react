import React from 'react';
import {NavLink} from "react-router-dom";
import Storage from "../../Classes/Storage";
import constantKey from "../../Config/ConstantKey";

// Category indexes are according all product page 
let cateIndexs = {
	badges:0,
	lanyardsSecurity:7,
	trolleyCoins:17,
	technology:15,
	powerrange:12
}

const setCateIndex = (catIndex) =>
{
	Storage.set(constantKey.catIndex,catIndex);
}

const ProductCategory = () => {
    return (
        <div className="hm-p-ctg">
			<div className="container">
				<h2 className="title">Product Categories</h2>
				<NavLink className="box" to="/product/all" onClick={()=>{setCateIndex(cateIndexs.badges)}}>
					<div className="content">
						<i className="fal fa-badge"></i>
						<div className="box-title">Badges</div>
					</div>
				</NavLink>
				<NavLink className="box" to="/product/all" onClick={()=>{setCateIndex(cateIndexs.lanyardsSecurity)}}>
					<div className="content">
						<i className="fal fa-id-card-alt"></i>
						<div className="box-title">Lanyards & Security</div>
					</div>
				</NavLink>
				<NavLink className="box" to="/product/all" onClick={()=>{setCateIndex(cateIndexs.trolleyCoins)}}>
					<div className="content">
						<i className="fal fa-shopping-cart"></i>
						<div className="box-title">Trolley Coins</div>
					</div>
				</NavLink>
				<NavLink className="box" to="/product/all" onClick={()=>{setCateIndex(cateIndexs.technology)}}>
					<div className="content">
						<i className="fal fa-mobile"></i>
						<div className="box-title">Technology</div>
					</div>
				</NavLink>
				<NavLink className="box" to="/product/all"  onClick={()=>{setCateIndex(cateIndexs.powerrange)}}>
					<div className="content">
						<i className="fal fa-bolt"></i>
						<div className="box-title">Power Range</div>
					</div>
				</NavLink>
				<div className="clearfix"></div>
				<NavLink className="btn btn-default btn-orng" to="/product/all">More Categories</NavLink>
			</div>
		</div>
    );
};

export default ProductCategory;