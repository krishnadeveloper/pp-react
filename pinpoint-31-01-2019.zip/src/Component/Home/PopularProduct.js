import React from 'react';
import HomeModel from "../../Model/Home";
import { NavLink } from "react-router-dom";

class PopularProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			loading: true,
			allPopularProducts: '',
		}
	}

	componentWillMount() {
		HomeModel.popularProduct().then(res => {

			if (!res.data.hasOwnProperty('error') && res.data.hasOwnProperty('response')) {

				this.setState(prevState => {
					return {
						loading: false,
						allPopularProducts: res.data.response
					}
				})
			}
			else {
				this.setState(prevState => {
					return {
						loading: false,
						allPopularProducts: ''
					}
				})
			}
		})
	}

	render() {

		return (
			<div class="popular-products">
				<div class="container">
					<h2 class="title">Popular Products</h2>
					<div class="row">
						{

							this.state.allPopularProducts ?
								this.state.allPopularProducts.length > 0 ?

									this.state.allPopularProducts.map(newProd => {
										
										return (
											<div class="col-xs-6 col-sm-6 col-md-3">
												<NavLink to={`/product/${newProd.reference}`}>

													<div class="product-panel">
														<div class="p-img">
															<img alt={newProd.name} src={newProd.img?newProd.img:newProd['images-thumbs'].length>0?newProd['images-thumbs'][0]:'/public/img/logo-g.svg'} height={25} class="img-responsive" />
														</div>
														<div class="p-title">{newProd.name}</div>
													</div>
												</NavLink>
											</div>
										)
									})

									:

									<div className="col-xs-12 col-sm-12 col-md-12">
										<p>No data found</p>
									</div>
								:
								''

						}

					</div>
				</div>
			</div>
		);
	}
};

export default PopularProduct;