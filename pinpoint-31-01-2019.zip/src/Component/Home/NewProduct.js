import React from 'react';
import HomeModel from "../../Model/Home";
import {NavLink} from "react-router-dom";


class NewProduct extends React.Component {
	
	constructor(props) {
		super(props);
		this.state ={
			loading:true,
			allNewProducts:'',
		}
	}
	

	componentWillMount()
	{
		HomeModel.newProduct().then(res=>{

			if(!res.data.hasOwnProperty('error') && res.data.hasOwnProperty('response'))
			{
				
				this.setState(prevState=>{
					return{
						loading:false,
						allNewProducts:res.data.response
					}
				})
			}
			else
			{
				this.setState(prevState=>{
					return{
						loading:false,
						allNewProducts:''
					}
				})
			}	
		})
	}

	render(){

	

    return (
        <div class="new-products">
			<div class="container">
				<h2 class="title">New Products</h2>
				<div class="row">
					{
						
						this.state.allNewProducts?
							this.state.allNewProducts.length>0?

								this.state.allNewProducts.map(newProd=>{
									
									return(
										<div class="col-xs-6 col-sm-6 col-md-3">
											<NavLink to={`/product/${newProd.reference}`}>

												<div class="product-panel">
													<div class="p-img">
														<img alt={newProd.name} src={newProd.img?newProd.img:newProd['images-thumbs'].length>0?newProd['images-thumbs'][0]:'/public/img/logo-g.svg'} height={25} class="img-responsive" />
													</div>
													<div class="p-title">{newProd.name}</div>
												</div>
											</NavLink>
										</div>
									)
								})
								
								:
							
								<div className="col-xs-12 col-sm-12 col-md-12">
									<p>No data found</p>
								</div>
						:
						''
			
					}
					
				</div>
			</div>
		</div>
	);
}
};

export default NewProduct;