import React from 'react';
import {NavLink} from "react-router-dom";
import SearchModel from "../../Model/Search";

function createData(id,name,image,ref){
    return {id,name,image,ref};
}



class Category extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            loading:true,
            products:[],
            catSlug:props.match.params.catSlug,
            message:''
        }
        this.fetchCategoryProduct = this.fetchCategoryProduct.bind(this);
    }
    
    fetchCategoryProduct = () =>{
        SearchModel.findProduct(`products/category/${this.state.catSlug}`).then(products=>{
            if(!products.data.hasOwnProperty('error') && products.data.hasOwnProperty('response')){
                let Product = [];
                let allProducts = [];

                var ukbb = false;
                for (var i = products.data.response.length - 1; i > -1; i--) {
                    if (products.data.response[i]['images-local']) products.data.response[i].img = products.data.response[i]['images-local'];
                    else if (products.data.response[i]['images'] && products.data.response[i]['images'].length > 0) products.data.response[i].img = products.data.response[i]['images'][0];
                    else {
                        products.data.response[i].img = products.data.response[i]['img-local-m'] ? products.data.response[i]['img-local-m'] : (products.data.response[i].img == null ? products.data.response[i].img : products.data.response[i].img + '/m');
                    }
                    if (products.data.response[i].reference.substr(0, 4) === 'UKBB') {
                        if (!ukbb) {
                            products.data.response[i].name = 'Button Badges';
                            products.data.response[i].reference = 'UKBB';
                            ukbb = true;
                        }
                        else {
                            products.data.response.splice(i, 1);
                        }
                    }

                }
                products.data.response.sort(function (a, b) {

                    if (!a['web-order'] && !b['web-order']) {
                        return a['name'].localeCompare(b['name']);
                    }
                    else if (!b['web-order'] || b['web-order'] === '0') return -1;
                    else if (!a['web-order'] || a['web-order'] === '0') return 1;
                    else return Number(a['web-order']) - Number(b['web-order']);
                });
    
                allProducts = products.data.response;
                
                allProducts.map(prod=>{
                    return Product.push(createData(prod.id,prod.name,prod.img,prod.reference));
                })
                this.setState(prevState=>{
                    return {
                        loading:false,
                        products:Product
                    }
                })
            }
            else
            {
                this.setState(prevState=>{
                    return {
                        loading:false,
                        products:[],
                        message:products.data.response.message
                    }
                }) 
            }
            
        }).catch(error=>{
            console.log(error);
            // this.setState(prevState=>{
            //     return{
            //         loading:false,
            //         products:[],
            //         catSlug:this.props.match.params.catSlug,
            //         message:error.response.statusText
            //     }
            // })

        })

        
        
    }

    componentWillMount(){
        this.fetchCategoryProduct();
    }

    render() {
        //SearchModel.findProduct('products/category/golf');
        return (
            <div class="popular-products">
                <div class="container">
                    <h2 class="title">{this.state.catSlug}</h2>
                    <div class="row">
                        {
                            
                            (this.state.loading===false && this.state.products.length>0)
                                ?   this.state.products.map(prodData=>{
                                    return(
                                        <div class="col-xs-6 col-sm-6 col-md-3" key={prodData.id}>
                                            <NavLink to={`/product/${prodData.ref}`}>
                                                <div class="product-panel">
                                                    <div class="p-img">
                                                        <img alt={prodData.name} src={prodData.image} class="img-responsive" />
                                                    </div>
                                                    <div class="p-title">{prodData.name}</div>
                                                </div>
                                            </NavLink>
                                        </div>
                                    )
                                })
                                : this.state.loading===true
                                    ?'Please wait while data is loading...'
                                    :'No record found'
                        }
                    </div>
                </div>
            </div>
        );
    }
};

export default Category;