import React from 'react';
import { NavLink } from "react-router-dom";
import Category from './Leftfilter/Category';
import Leadtime from './Leftfilter/Leadtime';
import Moq from './Leftfilter/Moq';
import Budget from './Leftfilter/Budget';
import Otherfilter from './Leftfilter/Otherfilter';

import Checkbox from "../../Classes/Checkbox";
import URL from "../../Classes/Url";
import AllproductModel from "../../Model/Allproduct";
import Auth from "../../Classes/Auth";

import Storage from "../../Classes/Storage";
import constantKey from "../../Config/ConstantKey";


let showProducts = 18;
let pages = 0;
let paginationText = '';

require('./css/products.css');


function createData(id,name,img,ref,price)
{
    return {id,name,img,ref,price}
}

let filterString = {
    leadtime:''
}

class Allproduct extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            search:{
                page:1,
                categories:'',
                leadtime:'',
                budget:'0_200',
                extras:'',
                moq:'0_50000',
                sort:'A-Z',
            },
            loading:true,
            products:[]
        }
        this.handleCheckbox = this.handleCheckbox.bind(this);
        this.handleRangeslider = this.handleRangeslider.bind(this);
        this.SearchAll = this.SearchAll.bind(this);
        this.handleSort = this.handleSort.bind(this);
        this.handlePage = this.handlePage.bind(this);
        this.handleCheckboxByname = this.handleCheckboxByname.bind(this);
    }

    componentWillMount(){
        this.SearchAll()
    }

    handleCheckbox = (e) =>{
        
        let name = e.target.name;
        this.setState(prevState=>{
            return{
                
                loading:true,
                products:[],
                search:{
                    ...prevState.search,
                    [name]:Checkbox.getCheckedFilter(name,filterString.hasOwnProperty(name)).join('_'),
                }
                
            }
        })
        
    }

    handleCheckboxByname = (name) =>{
        //let name = name;
        this.setState(prevState=>{
            return{
                
                loading:true,
                products:[],
                search:{
                    ...prevState.search,
                    [name]:Checkbox.getCheckedFilter(name,filterString.hasOwnProperty(name)).join('_'),
                }
                
            }
        })

        console.log('yes');
    }

    handleSort = (e) =>{
        let name = e.target.name;
        let val = e.target.value;
        this.setState(prevState=>{
            return{
                loading:true,
                products:[],
                search:{
                    ...prevState.search,
                    [name]:val
                }
            }
        })

    }



    handleRangeslider = (name,range)=>{

        this.setState(prevState=>{
            return{
                loading:true,
                products:[],
                search:{
                    ...prevState.search,
                    [name]:range.min+'_'+range.max
                }
            }
        })

    }

    handlePage = (pageNo) =>{
        paginationText = '';
        this.setState(prevState=>{
            return{
                search:{
                    page:pageNo,
                    categories:this.state.search.categories,
                    leadtime:this.state.search.leadtime,
                    moq:this.state.search.moq,
                    budget:this.state.search.budget,
                    extras:this.state.search.extras,
                    sort:this.state.search.sort,
                },
                loading:true,
                products:[]
            }
        })

    }


    SearchAll = () =>{
        
        AllproductModel.search(URL.httpBuildQuery(this.state.search)).then(products=>{
            if(!products.data.hasOwnProperty('error') && products.data.hasOwnProperty('response')){
                let Product = [];
                let allProducts = [];
                //var ukbb = false;
                for (var i = products.data.response.length - 1; i > -1; i--) {
                    if (products.data.response[i]['images-local']) products.data.response[i].img = products.data.response[i]['images-local'];
                    else if (products.data.response[i]['images'] && products.data.response[i]['images'].length > 0) products.data.response[i].img = products.data.response[i]['images'][0];
                    else {
                        products.data.response[i].img = products.data.response[i]['img-local-m'] ? products.data.response[i]['img-local-m'] : (products.data.response[i].img == null ? products.data.response[i].img : products.data.response[i].img + '/m');
                    }
                    // if (products.data.response[i].reference.substr(0, 4) === 'UKBB') {
                    //     if (!ukbb) {
                    //         products.data.response[i].name = 'Button Badges';
                    //         products.data.response[i].reference = 'UKBB';
                    //         ukbb = true;
                    //     }
                    //     else {
                    //         products.data.response.splice(i, 1);
                    //     }
                    // }

                }
                // products.data.response.sort(function (a, b) {

                //     if (!a['web-order'] && !b['web-order']) {
                //         return a['name'].localeCompare(b['name']);
                //     }
                //     else if (!b['web-order'] || b['web-order'] === '0') return -1;
                //     else if (!a['web-order'] || a['web-order'] === '0') return 1;
                //     else return Number(a['web-order']) - Number(b['web-order']);
                // });
    
                allProducts = products.data.response;
                paginationText = '';
                pages = Math.ceil((parseInt(products.data.totalproducts)/showProducts).toFixed(2));
                for (let index = 1; index < pages; index++) {

                    paginationText += '~!';
                    
                }
                               
                allProducts.map(prod=>{
                    return Product.push(createData(prod.id,prod.name,prod.img,prod.reference,prod.price));
                })
                this.setState(prevState=>{
                    return {
                        loading:false,
                        products:Product
                    }
                })
            }
            else
            {
                this.setState(prevState=>{
                    return {
                        loading:false,
                        products:[],
                    }
                }) 
            }

        })

        
    }

    
    componentDidUpdate(){

        if(this.state.loading)
        {
            this.SearchAll();
        }


        //Perform search action when user click on any category on home page
        if(Storage.get(constantKey.catIndex)){
            Storage.remove(constantKey.catIndex)
            this.handleCheckboxByname('categories')
        }
        
    }
    

    render() {
        return (
            <div className="main-content products-screen">
                <div className="main-title">
                    <div className="container">
                        <h2>All Products</h2>
                    </div>
                </div>
                <div className="products-area">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-3">
                                <div className="products-sidebar">
                                    <div className="title">Filter your search</div>
                                    <div className="sidebar-widget">
                                        <Category name="categories" homePageCateSearch={this.handleCheckboxByname} isLogon={Auth.isLogin()} checkCheckbox={this.handleCheckbox} />
                                    </div>
                                    <div className="sidebar-widget">
                                        <Leadtime name="leadtime" isLogon={Auth.isLogin()} checkCheckbox={this.handleCheckbox}/>
                                    </div>
                                    <div className="sidebar-widget">
                                        <Moq name="moq" isLogon={Auth.isLogin()}  rangeVal={this.handleRangeslider}/>
                                    </div>
                                    <div className="sidebar-widget">
                                        <Budget name="budget" isLogon={Auth.isLogin()} rangeVal={this.handleRangeslider}/>
                                    </div>
                                    <div className="sidebar-widget">
                                        <Otherfilter name="extras" isLogon={Auth.isLogin()} checkCheckbox={this.handleCheckbox} />
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-9">
                                <div className="products-top-bar">
                                    {/* <div className="pull-left"><p>Showing 1–12 of 20 result</p></div> */}
                                    <div className="sort-select">
                                        <form className="form-horizontal">
                                            <div className="form-group">
                                                <label className="col-sm-5 control-label">Sort by</label>
                                                <div className="col-sm-7">
                                                    <select className="form-control" name="sort" onChange={this.handleSort}>
                                                        <option value="A-Z">Name (A-Z)</option>
                                                        <option value="Z-A">Name(Z-A)</option>
                                                        <option value="low">Price - Lowest to highest</option>
                                                        <option value="high">Price - Highest to lowest</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div className="clearfix"></div>
                                <div className="row products-bottom-area">
                                    {
                                        (this.state.loading===false && this.state.products.length>0)
                                        ?
                                            this.state.products.map(prod=>{
                                                return(
                                                    <div className="col-sm-6 col-md-4" key={prod.id}>
                                                        <div className="product-panel">
                                                            <div className="p-img">
                                                                <NavLink to={`/product/${prod.ref}`}><img alt={prod.name} src={prod.img} className="img-responsive" /></NavLink>
                                                            </div>
                                                            <div className="p-title">
                                                                <NavLink to={`/product/${prod.ref}`}>{prod.name}</NavLink>
                                                                {
                                                                    Auth.isLogin()
                                                                    ?
                                                                        <NavLink to={`/product/${prod.ref}`} className="login-link"> From &pound;{prod.price}</NavLink>
                                                                    :
                                                                        <NavLink to="/index.php/auth/login" className="login-link">Login to view prices</NavLink>
                                                                }
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })
                                        :
                                            this.state.loading
                                            ?
                                                <div className="loader"><div className="loading"></div></div>
                                            :
                                            'No product found'
                                    }
                                    

                                </div>
                                <div className="products-pagination">
                                    <ul className="pagination">
                                        {
                                            paginationText.split('~').map((page,index)=>{
                                                return(<li><a href={()=>{}} onClick={()=>{this.handlePage(index+1)}}>{index+1}</a></li>)
                                            })   
                                        }
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="clearfix"></div>
            </div>
        );
    }
};

export default Allproduct;