import Allproduct from "./Allproduct";

export default Allproduct;