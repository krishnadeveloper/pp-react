import React from 'react';

const Leadtime = (props) => {
    return (
        <React.Fragment>
            <div className="widget-title">Lead time </div>
            <input id="collapsible2" className="toggle" type="checkbox" />
            <label for="collapsible2" className="lbl-toggle"></label>
            <ul className="sidebar-height-widget">
                <li className="checkbox"><label>1 - 10 days<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>2 weeks<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>3 weeks<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>4 weeks<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>6 weeks<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
            </ul>
        </React.Fragment>
    );
};

export default Leadtime;