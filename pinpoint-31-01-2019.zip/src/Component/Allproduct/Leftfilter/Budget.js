import React from 'react';
import BudgetSlider from "react-input-range";
import { NavLink } from "react-router-dom";

class Budget extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: { min: 54, max: 120 },
            minValue: 54,
            maxValue: 120
        };
        this.handleFilter = this.handleFilter.bind(this);
    }

    //Change state on change of filter value
    handleFilter = (v) => {
        this.setState({
            value: v,//value reflect on filter               
            minValue: v.min,//Min value
            maxValue: v.max//max value
        })
    }

    handleValue = (e) => {
        this.setState({
            [e.target.name]: e.target.value,
        }, () => {
            this.setState({
                value: { min: this.state.minValue, max: this.state.maxValue }
            })
            this.props.rangeVal('moq', this.state.value);
        })
    }


    render() {
        return (
            <React.Fragment>
                <div className="widget-title">Budget</div>
                <input id="collapsible4" className="toggle" type="checkbox" />
                <label for="collapsible4" className="lbl-toggle"></label>
                <div className="sidebar-height-widget rsliders">
                    {
                        this.props.isLogon
                            ?
                            <React.Fragment>
                                <BudgetSlider
                                    name={this.props.name}
                                    minValue={0.01}
                                    maxValue={200.00}
                                    step={10}
                                    formatLabel={value => value.toFixed(2)}
                                    formatLabel={value => `£${value}`}
                                    value={this.state.value}
                                    onChange={value => { this.handleFilter(value) }}
                                    onChangeComplete={() => this.props.rangeVal('moq', this.state.value)}
                                />
                                <div className="budget-sliders">
                                    <div className="col-xs-6">
                                        <input type="text" placeholder="Min." name='minValue' onChange={this.handleValue} value={this.state.minValue} className="form-control" max="50000" />
                                    </div>
                                    <div className="col-xs-6">
                                        <input type="text" placeholder="Max." name='maxValue' onChange={this.handleValue} value={this.state.maxValue} className="form-control" />
                                    </div>
                                </div>
                                <p align="center"><small>per unit</small></p>
                            </React.Fragment>
                            :
                            <React.Fragment>
                                <p>You must be logged in to view our prices {this.props.isLogin}</p>
                                <NavLink to="/index.php/auth/login">Login</NavLink>
                                <NavLink to="/apply-to-login"><small>Need an account? Apply today</small></NavLink>
                            </React.Fragment>
                    }
                </div>
            </React.Fragment>
        );
    }
};

export default Budget;