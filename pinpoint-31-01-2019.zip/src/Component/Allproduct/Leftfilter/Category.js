import React from 'react';
import Search from "../../../Model/Search";
import constantKey from "../../../Config/ConstantKey";
import Storage from "../../../Classes/Storage";

class Category extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            loading:true,
            categories:'',
            catIndex:{}
        }
    }

    componentWillMount(){
        
        Search.searchAll('products/categories').then(category=>{
            console.log(parseInt(false))
            let homeCatSelected = Storage.get(constantKey.catIndex);
            let catIndex = {}
                    
            if(!homeCatSelected)
            {
                Object.values(category.data.response).sort().map((val,key)=>{
                    catIndex[key]=true
                })
                
            }
            else
            {
                // Home page categorty selection process
                Object.values(category.data.response).sort().map((val,key)=>{
                    catIndex[key] = homeCatSelected==key?true:false
                })

            }

            this.setState(prevState=>{
                return {
                    loading:false,
                    categories:Object.values(category.data.response).sort(),
                    catIndex:catIndex
                }
            })
        }).catch(err=>{
            this.setState(prevState=>{
                return {
                    loading:false,
                    categories:''
                }
            })
        })
    }


    handleCheck = (e) =>{
        
        let catIndex = e.target.getAttribute('index');
        let catIndexAll = this.state.catIndex;
        catIndexAll[catIndex] = !this.state.catIndex[catIndex]; // Checkbox check and uncheck
        
        this.setState(prevState=>{
            return {
                loading:prevState.loading,
                categories:prevState.categories,
                catIndex:catIndexAll
            }
        })
        this.props.checkCheckbox(e)
        
    }
    
    render(){
    
    return (
        <React.Fragment>
            <div className="widget-title">Categories </div>
            <input id="collapsible" className="toggle" type="checkbox" />
            <label for="collapsible" className="lbl-toggle"></label>
            <ul className="sidebar-height-widget">
                {
                    (this.state.loading===false && this.state.categories.hasOwnProperty('0'))
                    ? 
                        
                        Object.keys(this.state.categories).map(catKey=>{
                            return(
                                <li className="checkbox"><label>{this.state.categories[catKey]}<input checked={this.state.catIndex[catKey]} index={catKey} name={this.props.name} onChange={this.handleCheck} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                            )     
                        })
                    :
                        this.state.loading
                        ?
                            <li className="checkbox"><label><span ><i className="far fa-loading fa-spin"></i></span></label></li>
                        :
                            <li className="checkbox"><label>No category found</label></li>
                }
                
                
            </ul>
        </React.Fragment>
    );
}
};

export default Category;