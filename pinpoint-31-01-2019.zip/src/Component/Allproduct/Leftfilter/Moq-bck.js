import React from 'react';
import MoqRange from "react-input-range";
import {NavLink} from "react-router-dom";
require('../css/rangeslider.css')

class Moq extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: { min: 1, max: 50000 },
          };
    }
    

    render() {
        return (
            <React.Fragment>
                <div className="widget-title">MOQ</div>
                <input id="collapsible3" className="toggle" type="checkbox" />
                <label for="collapsible3" className="lbl-toggle"></label>
                <div className="sidebar-height-widget" style={{padding:15}}>
                    {
                        this.props.isLogon
                        ?
                            <React.Fragment>
                                <MoqRange
                                name={this.props.name}
                                minValue={1}
                                maxValue={50000}
                                step={100}
                                value={this.state.value}
                                onChange={value => this.setState({ value })}
                                onChangeComplete={() => this.props.rangeVal('moq', this.state.value)}
                            />
                            <p align="center">Units</p>
                            </React.Fragment>
                        :
                        <React.Fragment>
                            <p>You must be logged in to view our prices {this.props.isLogin}</p>
                            <NavLink to="/index.php/auth/login">Login</NavLink>
                            <NavLink to="/apply-to-login"><small>Need an account? Apply today</small></NavLink>
                        </React.Fragment>

                    }
                    
                    
                </div>
            </React.Fragment>
        );
    }
};

export default Moq;