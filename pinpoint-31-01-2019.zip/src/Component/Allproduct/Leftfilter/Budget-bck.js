import React from 'react';
import BudgetSlider from "react-input-range";
import {NavLink} from "react-router-dom";

class Budget extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: { min: 1, max: 200.00 },
          };

    }
    

    render() {
        return (
            <React.Fragment>
                <div className="widget-title">Budget</div>
                <input id="collapsible4" className="toggle" type="checkbox" />
                <label for="collapsible4" className="lbl-toggle"></label>
                <div className="sidebar-height-widget" style={{padding:15}}>
                    {
                        this.props.isLogon
                        ?
                            <React.Fragment>
                                <BudgetSlider
                                name={this.props.name}
                                minValue={1}
                                maxValue={200.00}
                                step={10}
                                value={this.state.value}
                                onChange={value => this.setState({ value })}
                                onChangeComplete={() => this.props.rangeVal('budget', this.state.value)}
                            />
                            <p align="center">Per Unit</p>
                            </React.Fragment>
                        :
                        <React.Fragment>
                            <p>You must be logged in to view our prices {this.props.isLogin}</p>
                            <NavLink to="/index.php/auth/login">Login</NavLink>
                            <NavLink to="/apply-to-login"><small>Need an account? Apply today</small></NavLink>
                        </React.Fragment>
                    }
                    
                    {/* <p>You must be logged in to view our prices</p>
                <a href="#">Login</a>
                <a href=""><small>Need an account? Apply today</small></a> */}
                </div>
            </React.Fragment>
        );
    }
};

export default Budget;