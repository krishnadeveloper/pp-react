import React from 'react';

const Otherfilter = (props) => {
    return (
        <React.Fragment>
            <div className="widget-title">Other filters</div>
            <input id="collapsible5" className="toggle" type="checkbox" />
            <label for="collapsible5" className="lbl-toggle"></label>
            <ul className="sidebar-height-widget">
                <li className="checkbox"><label>Full color print<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>Pantone matched<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>Eco-friendly<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                <li className="checkbox"><label>UK products<input name={props.name} onChange={props.checkCheckbox} type="checkbox" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
            </ul>
        </React.Fragment>
    );
};

export default Otherfilter;