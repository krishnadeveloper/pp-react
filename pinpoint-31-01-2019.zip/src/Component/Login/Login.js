import React from 'react';
import {NavLink} from "react-router-dom";
require('./css/login.css');
const Login = () => {
    document.title = 'Pinpoint - Login';
    return (
        <div class="main-content login-screen">
            <div class="container">
                <div class="login-box">
                    <h3 class="title">Login to your account</h3>
                    <form>
                        <div class="form-group">
                            <label for="email">Email address</label>
                            <input type="email" class="form-control" name="email" id="email" required />
                        </div>
                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password" id="password" required />
                        </div>
                        <button type="submit" class="btn btn-default btn-orng btn-block">Login</button>
                    </form>
                    <p class="help"><NavLink to="/contact">Need an account? Apply today</NavLink></p>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    );
};

export default Login;