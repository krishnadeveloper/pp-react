import React from 'react';
import SearchModel from "../../Model/Search";
import Storage from "../../Classes/Storage";
import constantKey from '../../Config/ConstantKey';
import {NavLink} from "react-router-dom";
//https://www.pinpoint.promo/api?req=products%2Fcategory%2Fgolf')

function createData(name,image,ref) {
    return {name,image,ref};
} 

class Search extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            loading:true,
            searchData:[],
            keyword:props.match.params.keyword,
        }
        this.SearchProduct = this.SearchProduct.bind(this);
    }


    SearchProduct = () => {
        
        let keyword = Storage.get(constantKey.headerSearch);
        this.setState({
            loading:true
        })
        SearchModel.searchAll(`products/search/${keyword}`).then(res => {
            if (!res.data.hasOwnProperty('error') && res.data.hasOwnProperty('response')) {
                
                let pData = [];

                for (var i = res.data.response.length - 1; i > -1; i--) {
                    if (res.data.response[i]['images-local']) res.data.response[i].img = res.data.response[i]['images-local'];
                    else if (res.data.response[i]['images'] && res.data.response[i]['images'].length > 0) res.data.response[i].img = res.data.response[i]['images'][0];
                    else {
                        res.data.response[i].img = res.data.response[i]['img-local-m'] ? res.data.response[i]['img-local-m'] : (res.data.response[i].img == null ? res.data.response[i].img : res.data.response[i].img + '/m');
                    }
                }

                res.data.response.map(prod=>{
                    return pData.push(createData(prod.name,prod.img,prod.reference));
                })

                this.setState(prevState=>{
                    return {
                        loading:false,
                        searchData: pData,
                        keyword:keyword
                    }
                })
            } else {
                this.setState(prevState=>{
                    return {
                        loading:false,
                        searchData:[],
                        keyword:keyword
                    }
                })
            }
        });   
    }
    componentWillMount(){
        this.SearchProduct();
    }

    componentWillReceiveProps() {
        this.props.match.params.keyword = Storage.get(constantKey.headerSearch);
        this.SearchProduct();
    }
    render() {
        return (
            <div class="popular-products">
                <div class="container">
                    <h2 class="title">Search for '{this.state.keyword}'</h2>
                    <div class="row">
                        {
                            
                            (this.state.loading===false && this.state.searchData.length>0)
                                ?   this.state.searchData.map(prodData=>{
                                    return(
                                        <div class="col-xs-6 col-sm-6 col-md-3" key={prodData.ref}>
                                            <NavLink to={`/product/${prodData.image}`}>
                                                <div class="product-panel">
                                                    <div class="p-img">
                                                        <img alt="pinpoint" src={prodData.image} class="img-responsive" />
                                                    </div>
                                                    <div class="p-title">{prodData.name}</div>
                                                </div>
                                            </NavLink>
                                        </div>
                                    )
                                })
                                : this.state.loading===true
                                    ?
                                        <div className="loader"><div className="loading"></div></div>
                                    :
                                        'No record found'
                        }

                        {
                            
                        }
                        
                    </div>
                </div>
            </div>
        );
    }
};

export default Search;