import React from 'react';
require('./css/contact.css');
const Contact = () => {
    document.title = 'Pinpoint - Contact';
    return (
        <div class="main-content contact-screen">
            <div class="container">
                <div class="row">
                    <div class="col-sm-7">
                        <h3 class="title">Contact us</h3>
                        <p>Have a question for our team? Get in touch today</p>
                        <div class="contact-content">
                            <div class="row">
                                <div class="col-xs-1"><p><i class="fal fa-phone"></i></p></div>
                                <div class="col-xs-11"><p><a href="tel:02083028008">020 8302 8008</a></p></div>
                            </div>
                            <div class="row">
                                <div class="col-xs-1"><p><i class="fal fa-envelope"></i></p></div>
                                <div class="col-xs-11"><p><a href="mailto:sales@pinpoint.promo">sales@pinpoint.promo</a></p></div>
                            </div>
                            <div class="row">
                                <div class="col-xs-1"><p><i class="fal fa-building"></i></p></div>
                                <div class="col-xs-11"><p>Pinpoint Badgs & Promotions Ltd Churchill House Maltings Mews Sidcup, Kent DA15 7DG, United Kingdom</p>
                                    <p><a href={()=>{}}>View on Google Maps</a></p></div>
                            </div>
                            <div class="contact-social">
                                <div class="title">Follow us on social media</div>
                                <ul class="list-inline">
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.facebook.com/pinpoint1980','_blank')}} class="facebook"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://twitter.com/pinpoint1980','_blank')}} class="twitter"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.instagram.com/pinpoint1980','_blank')}} class="instagram"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.youtube.com/watch?v=kW9ux_u_boc','_blank')}} class="youtube"><i class="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <div class="contact-form">
                            <h4>Use the form bleow to send us a message</h4>
                            <form>
                                <div class="form-group">
                                    <label for="name">Full Name<span>*</span></label>
                                    <input type="text" class="form-control" name="name" id="name" required />
                                </div>
                                <div class="form-group">
                                    <label for="cname">Company Name<span>*</span></label>
                                    <input type="text" class="form-control" name="cname" id="cname" required />
                                </div>
                                <div class="form-group">
                                    <label for="email">Email address<span>*</span></label>
                                    <input type="email" class="form-control" name="email" id="email" required />
                                </div>
                                <div class="form-group">
                                    <label for="message">Message<span>*</span></label>
                                    <textarea class="form-control" rows="5" id="message" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-default btn-orng btn-block">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    );
};

export default Contact;