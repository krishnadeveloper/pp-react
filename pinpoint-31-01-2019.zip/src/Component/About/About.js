import React from 'react';
require('./css/page.css')
const About = () => {
    return (
        <div class="main-content page-screen">
            <div class="page-title">
                <div class="container">About us</div>
            </div>
            <div class="container page-content">
                <h2></h2>
                <p>Pinpoint are a trade only supplier which have been trading for over 39 years. With a wealth of experience in promotional products.</p>
                <p>Pinpoint have seen rapid growth within the last few years and have recently opened a China office to allow for a seamless ordering experience. With our China office we have introduced a sourcing service which we firmly believe is the best within the industry.</p>
                <p>Pinpoint will go above and beyond with each enquiry to ensure your customer is satisfied, contact us today to see how we can help you.</p>
            </div>
            <div class="clearfix"></div>
        </div>
    );
};

export default About;