import Testimonial from "./Testimonial";

export default Testimonial;