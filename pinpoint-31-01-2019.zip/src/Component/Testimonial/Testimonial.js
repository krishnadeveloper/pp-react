import React from 'react';
require('./css/testimonials.css');

const Testimonial = () => {
    return (
        <div className="main-content testimonials-screen">
				<div className="testimonials-title">
					<div className="container">Testimonials</div>
				</div>
				<div className="testimonials-content">
					<div className="container">
						<div className="row">
							<div className="col-xs-12 col-lg-6 col-md-6">
								<div className="box">
									<div className="box-content">
										<p>The Pinpoint team are fantastic, They respond to all enquiries within minutes which is great when you just want to get the quote off to your client. They are great for sourcing any non-standard product. Our partnership is growing all the time and they offer us great support by attending internal and external company events. Pinpoint will always be my go to supplier for Far East products and Sourcing.</p>
										<h4>-Fluid Branding</h4>
										<div className="logo"><img src="/assets/img/fluid.png" className="img-responsive" alt="Pinpoint" /></div>
									</div>
								</div>
							</div>
							<div className="col-xs-12 col-lg-6 col-md-6">
								<div className="box">
									<div className="box-content">
										<p>The Pinpoint team are fantastic, They respond to all enquiries within minutes which is great when you just want to get the quote off to your client. They are great for sourcing any non-standard product. Our partnership is growing all the time and they offer us great support by attending internal and external company events. Pinpoint will always be my go to supplier for Far East products and Sourcing.</p>
										<h4>-Fluid Branding</h4>
										<div className="logo"><img src="/assets/img/fluid.png" className="img-responsive" alt="Pinpoint" /></div>
									</div>
								</div>
							</div>
							<div className="col-xs-12 col-lg-6 col-md-6">
								<div className="box">
									<div className="box-content">
										<p>The Pinpoint team are fantastic, They respond to all enquiries within minutes which is great when you just want to get the quote off to your client. They are great for sourcing any non-standard product. Our partnership is growing all the time and they offer us great support by attending internal and external company events. Pinpoint will always be my go to supplier for Far East products and Sourcing.</p>
										<h4>-Fluid Branding</h4>
										<div className="logo"><img src="/assets/img/fluid.png" className="img-responsive" alt="Pinpoint" /></div>
									</div>
								</div>
							</div>
							<div className="col-xs-12 col-lg-6 col-md-6">
								<div className="box">
									<div className="box-content">
										<p>The Pinpoint team are fantastic, They respond to all enquiries within minutes which is great when you just want to get the quote off to your client. They are great for sourcing any non-standard product. Our partnership is growing all the time and they offer us great support by attending internal and external company events. Pinpoint will always be my go to supplier for Far East products and Sourcing.</p>
										<h4>-Fluid Branding</h4>
										<div className="logo"><img src="/assets/img/fluid.png" className="img-responsive" alt="Pinpoint" /></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="clearfix"></div>
			</div>
    );
};

export default Testimonial;