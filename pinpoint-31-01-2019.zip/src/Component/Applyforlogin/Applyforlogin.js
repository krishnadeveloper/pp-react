import React from 'react';
require('./css/apply-account.css');
const Applyforlogin = () => {
    return (
        <div className="main-content apply-screen">
				<div className="page-title">
					<div className="container">Apply for a Login</div>
				</div>
				<div className="container">
					<div className="row">
						<div className="col-sm-7 apply-content">
							<h3 className="title">Apply for a trade login today</h3>
							<p>Please fill in the form and apply for a trade login today. Pinpoint are a trade only supplier so may ask for evidence to support your application. Once accepted you will have full access to:</p>
							<ul>
								<li>View our trade prices</li>
								<li>View your new and past orders online</li>
								<li>Get a dedicated account manager</li>
								<li>Trade accounts can apply for 30 day credit terms</li>
							</ul>
							<p>All trade account requests are reviewed within 24 hours.</p>
							<div className="space-30"></div>
							<div className="apply-help">
								<div className="title"><strong>Have a question?</strong> Get in touch with our team today</div>
								<div className="row">
									<div className="col-sm-6">
											<h3><i className="fal fa-phone"></i> <a href="tel:02083028008">020 8302 8008</a></h3>
									</div>
									<div className="col-sm-6">
										<h3><i className="fal fa-envelope"></i> <a href="mailto:sales@pinpoint.promo">sales@pinpoint.promo</a></h3>
									</div>
								</div>
							</div>
						</div>
						<div className="col-sm-5">
							<div className="apply-form">
								<h4>Apply for a trade account below</h4>
								<form>
									<div className="form-group">
										<label for="name">Full Name<span>*</span></label>
										<input type="text" className="form-control" name="name" id="name" required />
									</div>
									<div className="form-group">
										<label for="cname">Company Name<span>*</span></label>
										<input type="text" className="form-control" name="cname" id="cname" required />
									</div>
									<div className="form-group">
										<label for="email">Email address<span>*</span></label>
										<input type="email" className="form-control" name="email" id="email" required />
									</div>
									<div className="form-group">
										<label for="contact">Contact Number<span>*</span></label>
										<input type="text" className="form-control" name="contact" id="contact" required />
									</div>				
									<button type="submit" className="btn btn-lg btn-default btn-orng btn-block">Apply for an account</button>
								</form>
							</div>
						</div>
					</div>
				</div>

				<div className="clearfix"></div>
			</div>
    );
};

export default Applyforlogin;