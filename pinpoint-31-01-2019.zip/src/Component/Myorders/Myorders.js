import React from 'react';
import User from "../../Model/User";
var dateFormat = require('dateformat');

require('./css/orders.css');

const WAIT_INTERVAL = 1000;
class Myorders extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            searchData: [],
            products: [],
            ordernumber: '',
            designreference: '',
            invoicenumber: '',
            product: '',
            all_status: '',
            ordertime: '',
            arai: true,
            bapp: true,
            cdes: true,
            dinv: true,
            xcan: true,
            bfap: true,
            efac: true,
        }

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleCheckStatus = this.handleCheckStatus.bind(this);
        this.desellectAll = this.desellectAll.bind(this);
    }

    handleChange = (str) => {
        setTimeout(() => {
            this.Myorders();
        })
    }
    desellectAll = () => {
        this.setState({
            arai: false,
            bapp: false,
            cdes: false,
            dinv: false,
            xcan: false,
            bfap: false,
            efac: false,
        })
        setTimeout(() => {
            this.Myorders();
        })
    }
    handleCheckStatus = (str) => {
        if (str === "arai") {
            if (this.state.arai) {
                this.setState({
                    arai: false,
                })
            }
            else {
                this.setState({
                    arai: true,
                })
            }
        }

        if (str === "bapp") {
            if (this.state.bapp) {
                this.setState({
                    bapp: false,
                })
            }
            else {
                this.setState({
                    bapp: true,
                })
            }
        }
        if (str === "cdes") {
            if (this.state.cdes) {
                this.setState({
                    cdes: false,
                })
            }
            else {
                this.setState({
                    cdes: true,
                })
            }
        }
        if (str === "dinv") {
            if (this.state.dinv) {
                this.setState({
                    dinv: false,
                })
            }
            else {
                this.setState({
                    dinv: true,
                })
            }
        }
        if (str === "xcan") {
            if (this.state.xcan) {
                this.setState({
                    xcan: false,
                })
            }
            else {
                this.setState({
                    xcan: true,
                })

            }
        }
        if (str === "bfap") {
            if (this.state.bfap) {
                this.setState({
                    bfap: false,
                })
            }
            else {
                this.setState({
                    bfap: true,
                })
            }
        }
        if (str === "efac") {
            if (this.state.efac) {
                this.setState({
                    efac: false,
                })
            }
            else {
                this.setState({
                    efac: true,
                })

            }
        }
    }
    handleSubmit = (event) => {
        console.log(this.timer)
        clearTimeout(this.timer);
        console.log(this.timer)
        this.setState({ [event.target.name]: event.target.value });
        //this.timer = setTimeout(::this.Myorders, WAIT_INTERVAL);
        this.timer = setTimeout(() => {
            this.Myorders();
        }, WAIT_INTERVAL)
    }
    Myorders = () => {
        this.setState({
            loading: true
        })
        let status = "";
        if (this.state.arai) {
            status += "arai_";
        } if (this.state.bapp) {
            status += "bapp_";
        } if (this.state.cdes) {
            status += "cdes_";
        } if (this.state.dinv) {
            status += "dinv_";
        } if (this.state.xcan) {
            status += "xcan_";
        } if (this.state.bfap) {
            status += "bfap_";
        } if (this.state.efac) {
            status += "efac_";
        }
        //console.log(status);
        User.findOrder(this.state.ordernumber, this.state.designreference, this.state.invoicenumber, this.state.product, this.state.ordertime, status).then(res => {
            console.log(res)
            if (res.status && res.status === 200 && res.data && res.data != null && res.data[0]['order-number'] != null) {
                this.setState(prevState => {
                    return {
                        loading: false,
                        searchData: res.data,
                        products: res.data[0]['name'],
                    }
                })
            } else {
                this.setState(prevState => {
                    return {
                        loading: false,
                        searchData: [],
                        products: res.data[0]['name'],
                    }
                })
            }
        });
    }
    componentWillMount() {
        this.Myorders();
        this.timer = null;
    }

    render() {
        return (
            <div>
                <div className="main-content orders-screen">
                    <div className="page-title">
                        <div className="container">My Orders</div>
                    </div>
                    <div className="container">
                        <div className="search-area">
                            <div>
                                <h3>Search for your orders</h3>
                                <input id="collapsible" className="toggle" type="checkbox" />
                                <label for="collapsible" className="lbl-toggle"></label>
                                <div className="form-inputs">
                                    <form onChange={this.handleSubmit}>
                                        <div className="space-20"></div>
                                        <div className="row">
                                            <div className="col-md-7">
                                                <div className="row">
                                                    <div className="col-sm-4">
                                                        <div className="form-group">
                                                            <label for="ordernumber">Order Number</label>
                                                            <input type="text" className="form-control" id="ordernumber" name="ordernumber" />
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-4">
                                                        <div className="form-group">
                                                            <label for="designreference">Design Reference</label>
                                                            <input type="text" className="form-control" id="designreference" name="designreference" />
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-4">
                                                        <div className="form-group">
                                                            <label for="invoicenumber">Invoice Number</label>
                                                            <input type="text" className="form-control" id="invoicenumber" name="invoicenumber" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-5">
                                                <div className="row">
                                                    <div className="col-sm-7">
                                                        <div className="form-group">
                                                            <label for="product">Product</label>
                                                            <select id="product" className="form-control" name="product">
                                                                <option value="">Select Product</option>
                                                                {
                                                                    Object.keys(this.state.products).map((item) => {
                                                                        return (
                                                                            <option value={item}>{this.state.products[item]}</option>
                                                                        )
                                                                    })
                                                                }
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-5">
                                                        <div className="form-group">
                                                            <label for="ordertime">Order Time</label>
                                                            <select id="ordertime" className="form-control" name="ordertime" onChange={this.handleSubmit}>
                                                                <option value="">Select Time Interval</option>
                                                                <option value="30">Last 30 Days</option>
                                                                <option value="60">Last 60 Days</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="space-20"></div>

                                    </form><div className="row">
                                        <div className="form-group">
                                            <div className="col-xs-12 col-sm-2">
                                                <label>Order Status</label>
                                            </div>
                                            <div className="col-xs-12 col-sm-10">
                                                <ul className="list-inline">
                                                    <li className="checkbox"><label>Raised<input type="checkbox" name="arai" checked={this.state.arai} onClick={(e) => { this.handleCheckStatus("arai"); this.handleChange(e) }} value="arai" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Approved<input type="checkbox" name="bapp" checked={this.state.bapp} onClick={(e) => { this.handleCheckStatus("bapp"); this.handleChange(e) }} /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Factory Approved<input type="checkbox" name="bfap" checked={this.state.bfap} onClick={(e) => { this.handleCheckStatus("bfap"); this.handleChange(e) }} value="bfap" /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Despatched<input type="checkbox" name="cdes" checked={this.state.cdes} onClick={(e) => { this.handleCheckStatus("cdes"); this.handleChange(e) }} /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Invoiced<input type="checkbox" name="dinv" checked={this.state.dinv} onClick={(e) => { this.handleCheckStatus("dinv"); this.handleChange(e) }} /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Factory Invoiced<input type="checkbox" name="efac" checked={this.state.efac} onClick={(e) => { this.handleCheckStatus("efac"); this.handleChange(e) }} /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li className="checkbox"><label>Cancelled<input type="checkbox" name="xcan" checked={this.state.xcan} onClick={(e) => { this.handleCheckStatus("xcan"); this.handleChange(e) }} /><span className="checkmark"><i className="far fa-check"></i></span></label></li>
                                                    <li><button type="button" className="btn-no" onClick={this.desellectAll}>Deselect all</button></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="space-20"></div>

                        {/*<div className="orders-top-bar clearfix">
                                                    <div className="pull-left"><p>{Showing 3 of 3 orders}</p></div>
                                                    <div className="sort-select">
                                                            <div className="form-group">
                                                                <div className="row">
                                                                    <label className="col-xs-3 control-label">Sort by</label>
                                                                    <div className="col-xs-9">
                                                                        <select className="form-control" name="sortkey" onChange={this.handleSubmit}>
                                                                            <option value="asc">Product Name (A-Z)</option>
                                                                            <option value="desc">Product Name (Z-A)</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                    </div>
                                                </div>*/}
                        <div className="clearfix"></div>
                        <div id="table">
                            {
                                (this.state.loading === false && this.state.searchData.length > 0)
                                    ? this.state.searchData.map(prodData => {
                                        return (
                                            <>
                                                <div className="table-responsive">
                                                    <table className="table">
                                                        <tbody>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <span className={prodData['order-status']}>Product</span>
                                                                    <span className="title">{prodData['product-name']}</span>
                                                                </td>
                                                                <td>
                                                                    <span>Quantity</span>
                                                                    <strong>{prodData['order-quantity']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Value (exc. VAT)</span>
                                                                    <strong>£{prodData['order-value']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span class="green">{prodData['order-status'] == 'arai' ? 'Raised' : (prodData['order-status'] == 'bapp' ? 'Approved' : (prodData['order-status'] == 'cdes' ? 'Despatched' : (prodData['order-status'] == 'dinv' ? 'Invoiced' : (prodData['order-status'] == 'xcan' ? 'Cancelled' : (prodData['order-status'] == 'bfap' ? 'Factory Approved' : (prodData['order-status'] == 'efac' ? 'Factory Invoiced' : ''))))))}</span>
                                                                    {
                                                                        (prodData['order-status'] == "cdes") ?
                                                                            <button className="btn btn-blue">Track Delivery <i className="fal fa-chevron-circle-right"></i></button>
                                                                            : ''

                                                                    }
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <span>Design Reference</span>
                                                                    <strong>{prodData['factory-design-reference']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Order No.</span>
                                                                    <strong>{prodData['order-number']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Their Order No.</span>
                                                                    <strong>{prodData['customer-order-number']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Invoice No.</span>
                                                                    <strong>{prodData['order-invoice-number']}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Order Date</span>
                                                                    <strong>{dateFormat(prodData['raise-create'], "dd/mm/yyyy")}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Approval Date</span>
                                                                    <strong>{dateFormat(prodData['app-date'], "dd/mm/yyyy")}</strong>
                                                                </td>
                                                                <td>
                                                                    <span>Delivery Date</span>
                                                                    <strong>{dateFormat(prodData['order-required-date'], "dd/mm/yyyy")}</strong>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </>
                                        )
                                    })
                                    : this.state.loading === true ? <div className="table-responsive">
                                        <table className="table">
                                            <tbody>
                                                <tr>
                                                    <td style={{ textAlign: 'center' }}>Please wait while data is loading...</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div> : <div className="table-responsive">
                                            <table className="table">
                                                <tbody>
                                                    <tr>
                                                        <td style={{ textAlign: 'center' }}>No record found</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                            }
                        </div>
                    </div>
                    <div className="clearfix"></div>
                </div>
                <div className="space-50"></div>
            </div>
        );
    }
}

export default Myorders;