import React from 'react';
import {NavLink} from "react-router-dom";
require('./css/404.css');

const Nomatch = () => {
    document.title = 'Pinpoint - 404 not found';
    return (
        <div class="main-content">
            <div class="error-content row">
                <div class="col-sm-4 brdr-rght">
                    <h1 class="title">404</h1>
                </div>
                <div class="col-sm-8">
                    <h2 class="sub-title">Sorry! The page you're looking for cannot be found.</h2>
                    <p>Go Back to <NavLink to="/">Home</NavLink> | <NavLink to="/about">About Us</NavLink> | <NavLink to="/contact">Request an account</NavLink></p>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    );
};

export default Nomatch;