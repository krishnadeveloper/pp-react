import React from "react";
import { BrowserRouter, Switch, Route,Redirect } from "react-router-dom";
/**
 * All component imported from path src/Component/{ComponenetName}
 */
import Home from "../Component/Home/Home";
import Contact from "../Component/Contact";
import Category from "../Component/Category";
import Product from "../Component/Product";
import Myorders from "../Component/Myorders";
import Nomatch from "../Component/Nomatch";
import Search from "../Component/Search";
import Header from "../Layout/Header";
import Footer from "../Layout/Footer";
import Login from "../Component/Login";
import Testimonial from "../Component/Testimonial";
import About from "../Component/About";
import Applyformlogin from "../Component/Applyforlogin";
import Allproduct from "../Component/Allproduct";
import Privacypolicy from "../Component/Privacypolicy/Privacypolicy";

const RedirectToHome = () =>{
    return(
        <Redirect to="/" />
    )
}

// Top level routing
const Router = () => {
    
    return (
        <BrowserRouter>
            <React.Fragment>
                <Header/>
                <Switch>

                    <Route
                        exact={true}
                        path="/index.php"
                        component={RedirectToHome}
                    />
                    <Route
                        exact={true}
                        path="/"
                        component={Home}
                        
                    />
                    <Route
                        path="/contact"                        
                        component={Contact}
                        
                    />

                    <Route
                        path="/category/:catSlug"
                        component={Category}
                        
                    />
                    
                    <Route
                        path="/product/all"
                        component={Allproduct}
                        
                    />

                    <Route
                        path="/product/:reference"                        
                        component={Product}
                        
                    />

                    <Route
                        path="/myorders"                        
                        component={Myorders}
                        
                    />

                    <Route
                        path="/login"                        
                        component={Login}
                        
                    />

                    <Route
                        path="/search/:keyword"
                        component={Search}
                        
                    />

                    <Route 
                        path="/testimonial"                        
                        component={Testimonial}
                        
                    />

                    <Route 
                        path="/about"                        
                        component={About}
                        
                    />

                    <Route 
                        path="/apply-to-login"                       
                        component={Applyformlogin}
                        
                    />

                    <Route 
                        path="/privacy-policy"
                        component={Privacypolicy}
                        
                    />


                    <Route component={Nomatch}  /> {/* Not found */}

                </Switch>
                <Footer/>
            </React.Fragment>
        </BrowserRouter>
    );
};

export default Router;
