import React from 'react';
import { NavLink } from "react-router-dom";

const TopFooter = (props) => {
	return (
		<div className="top-footer">
			{
				!props.userLogin
					?
					<div className="container">
						<div className="col-lg-8 col-sm-6"><h4>View our products and pricing here</h4></div>
						<div className="col-lg-4 col-sm-6 buttons">
							<NavLink to="/product/all" className="btn btn-default btn-orng">Products</NavLink>
						</div>
					</div>
					:
					<div className="container">
						<div className="col-lg-8 col-sm-6"><h4>Trade Customers only, log in to view prices</h4></div>
						<div className="col-lg-4 col-sm-6 buttons">
							<NavLink to="/apply-to-login" className="btn btn-default btn-orng">Request a Login</NavLink>
							<a href="/index.php/auth/login" className="btn btn-default btn-outline">Login</a>
						</div>
					</div>

			}

		</div>
	);
};

export default TopFooter;