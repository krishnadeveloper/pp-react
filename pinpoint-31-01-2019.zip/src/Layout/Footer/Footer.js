import React from 'react';
import TopFooter from './TopFooter';
import Auth from "../../Classes/Auth";
import { withRouter,NavLink } from "react-router-dom"

const Footer = () => {
        return (
            <React.Fragment>
                {console.log(Auth.isLogin())}
            <footer>
                
                    <TopFooter userLogin={Auth.isLogin()} />
                    <div className="container">
                        <div className="row">
                            <div className="col-sm-4 col-md-4">
                                <ul>
                                    <li><h4>Useful Links</h4></li>
                                    <li><NavLink to="/about">About Us</NavLink></li>
                                    <li><NavLink to="/testimonial">Testimonials</NavLink></li>
                                    <li><NavLink to="/privacy-policy">Privacy Policy</NavLink></li>
                                    <li><NavLink to="/product/all">Products</NavLink></li>
                                    <li><NavLink to="/contact">Contact Us</NavLink></li>
                                </ul>
                            </div>
                            <div className="col-sm-4 col-md-4">
                                <ul>
                                    <li><h4>Contact Us</h4></li>
                                    <li><i className="fas fa-phone"></i> 020 8302 8008</li>
                                    <li><i className="fas fa-envelope"></i> <a href="mailto:sales@pinpoint.promo">sales@pinpoint.promo</a></li>
                                </ul>
                                <ul className="list-inline footer-social">
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.facebook.com/pinpoint1980','_blank')}} className="facebook" ><i className="fab fa-facebook-f"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://twitter.com/pinpoint1980','_blank')}} className="twitter"><i className="fab fa-twitter"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.instagram.com/pinpoint1980','_blank')}} className="instagram"><i className="fab fa-instagram"></i></a></li>
                                    <li><a href={()=>{}} onClick={()=>{window.open('https://www.youtube.com/watch?v=kW9ux_u_boc','_blank')}} className="youtube"><i className="fab fa-youtube"></i></a></li>
                                </ul>
                            </div>
                            <div className="col-sm-4 col-md-4 f-address">
                                <div className="row">
                                    <div className="col-xs-2 no-p"><i className="fas fa-building"></i></div>
                                    <div className="col-xs-10">
                                        <p>Pinpoint Badgs & Promotions Ltd Churchill House Maltings Mews Sidcup, Kent DA15 7DG, United Kingdom</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="copyright">
                        <div className="container text-center">
                            <p>Copyright &copy; 2019. All Rights Reserved. Pinpoint Badges & Promotions Ltd. Company Reg No. 01475486.</p>
                        </div>
                    </div>
                </footer>
            </React.Fragment>
        );
};

export default withRouter(Footer);