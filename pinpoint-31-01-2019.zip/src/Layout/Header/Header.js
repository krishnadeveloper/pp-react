import React from 'react';
import Top from './Top';
import { withRouter, NavLink } from "react-router-dom";
import Storage from "../../Classes/Storage";
import constantKey from "../../Config/ConstantKey";
import Auth from "../../Classes/Auth";
import URL from "../../Classes/Url";
import Searchinput from './Searchinput';




class Header extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            search: '',
            isLogin: Auth.isLogin(),
            myorder: Auth.showMyorder()
        }
        // Method binding 
        this.handleHeaderSearch = this.handleHeaderSearch.bind(this);
        this.handleSearchInput = this.handleSearchInput.bind(this);
        this.checkLogin = this.checkLogin.bind(this);
        window.userid = 79;
    }

    /**
     * checkLogin works to check user login
     */
    checkLogin = () => {
        this.setState(prevState => {
            return {
                isLogin: Auth.isLogin(),
                showMyorder: Auth.showMyorder()
            }
        })
    }

    componentDidMount() {
        // validate user
        setTimeout(() => {
            this.checkLogin()
        }, 500)
    }

    componentDidUpdate(){
        
        URL.moveToTop()
    }

    handleSearchInput = (e) => {
        let inputValue = e.target.value;
        this.setState(prevState => {
            return {
                ...prevState,
                search: inputValue
            }
        })
    }

    handleSuggestionSearch = (suggestion) => {

        this.setState(prevState => {
            return {
                ...prevState,
                search: suggestion
            }
        })
    }

    

    handleHeaderSearch = (e) => {
        Storage.set(constantKey.headerSearch, this.state.search);
        this.props.history.push(`/search/${this.state.search}`);
    }

    render() {
        return (
            <React.Fragment>
                <header className="d_h hidden-xs">
                    <Top isLogin={this.state.isLogin} showMyorder={this.state.showMyorder} />
                    <div className="main-header">
                        <div className="container">
                            <div className="row logo-bar">
                                <div className="col-sm-4 col-md-3 col-lg-3">
                                    <div className="logo">
                                        <NavLink to="/"><img src="/assets/img/logo.svg" alt="Pinpoint Logo" className="img-responsive" /></NavLink>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-lg-offset-3 col-md-7 col-md-offset-2 col-sm-8">
                                    <div className="search-box">
                                        <div className="form-group">
                                            <Searchinput handleSearchInput={this.handleSuggestionSearch} />
                                            {/* <input type="text" name="search" className="form-control" onKeyUp={this.handleSearchInput} placeholder="Search our Products..." required /> */}
                                        </div>
                                        <button type="button" className="btn btn-default btn-orng" onClick={this.handleHeaderSearch}><i className="fal fa-search"></i> Search</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <nav className="navbar navbar-default navigation">
                            <div className="container">
                                <div className="navbar-header">
                                    <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                        <span className="sr-only">Toggle navigation</span>
                                        <span className="icon-bar"></span>
                                        <span className="icon-bar"></span>
                                        <span className="icon-bar"></span>
                                    </button>
                                </div>

                                <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul className="nav navbar-nav">
                                        <li><NavLink to="/product/all">Products</NavLink></li>
                                        <li><NavLink to="/about">About Us</NavLink></li>

                                        {
                                            this.state.isLogin
                                                ? <li><NavLink to="/myorders">My Orders</NavLink></li>
                                                : ''
                                        }

                                        {
                                            this.state.isLogin
                                                ? <li><a href="/index.php/auth/logout">Logout</a></li>
                                                :
                                                <React.Fragment>
                                                    <li><NavLink to="/apply-to-login">Request an Account</NavLink></li>
                                                    <li><a href="/index.php/auth/login">Login</a></li>
                                                </React.Fragment>

                                        }

                                    </ul>
                                    <ul className="nav navbar-nav navbar-right">
                                        <li><a href={() => { }}><i className="fal fa-phone"></i>020 8302 8008</a></li>
                                        <li><a href={() => { }}><i className="fal fa-envelope"></i>sales@pinpoint.promo</a></li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </div>
                </header>

                <header class="m_h visible-xs">
                    <div class="container m_navigation">
                        <div class="row m_t_h">
                            <div class="col-xs-2">
                                <input type="checkbox" class="openSidebarMenu" id="openSidebarMenu" />
                                <label for="openSidebarMenu" class="sidebarIconToggle">
                                    <div class="spinner diagonal part-1"></div>
                                    <div class="spinner horizontal"></div>
                                    <div class="spinner diagonal part-2"></div>
                                </label>
                                <div id="sidebarMenu">
                                    <ul class="sidebarMenuInner">
                                        <li><NavLink to="/">Home</NavLink></li>
                                        <li><NavLink to="/product/all">Products</NavLink></li>
                                        <li><NavLink to="/about">About Us</NavLink></li>
                                        <li><NavLink to="/contact">Contact Us</NavLink></li>
                                        <li><NavLink to="/apply-to-login">Apply for a login</NavLink></li>
                                        <li><NavLink to="/index.php/auth/login">Login to you account</NavLink></li>
                                    </ul>
                                    <ul class="info">
                                        <li><a href={()=>{}}><i class="fal fa-phone"></i>020 8302 8008</a></li>
                                        <li><a href={()=>{}}><i class="fal fa-envelope"></i>sales@pinpoint.promo</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-8">
                                <div class="logo">
                                    <NavLink to="/"><img alt="Pinpoint" src="/assets/img/logo.svg" class="img-responsive" /></NavLink>
                                </div>
                            </div>
                            <div class="col-xs-2">
                                {
                                    this.state.isLogin
                                        ?
                                        this.state.isLogin // redirect logged in user to their orders
                                            ?<NavLink to="/myorders"><i class="far fa-user-circle"></i></NavLink>
                                            :<NavLink to="/"><i class="far fa-user-circle"></i></NavLink>
                                    
                                        :<NavLink to="/index.php/auth/login"><i class="far fa-user-circle"></i></NavLink>

                                }
                                
                            </div>
                        </div>
                    </div>
                    <div class="m_s_b">
                        <form class="">
                            <div class="form-group">
                                <Searchinput handleSearchInput={this.handleSuggestionSearch} />
                            </div>
                            <button type="button" class="btn btn-default btn-orng" onClick={this.handleHeaderSearch}><i class="fal fa-search"></i></button>
                        </form>
                    </div>
                </header>
            </React.Fragment>
        );
    }
};

export default withRouter(Header);