import React from "react";
import Autosuggest from 'react-autosuggest';
import AllproductModel from "../../Model/Allproduct";
require('./search.css');

let productNames = [];

// https://developer.mozilla.org/en/docs/Web/JavaScript/Guide/Regular_Expressions#Using_Special_Characters
function escapeRegexCharacters(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function getSuggestions(value) {
    const escapedValue = escapeRegexCharacters(value.trim());

    if (escapedValue === '') {
        return [];
    }

    const regex = new RegExp('^' + escapedValue, 'i');

    return productNames.filter(productName => regex.test(productName.name));
}

function getSuggestionValue(suggestion) {
    return suggestion.name;
}

function renderSuggestion(suggestion) {
    return (
        <span>{suggestion.name}</span>
    );
}

class Searchinput extends React.Component {
    constructor() {
        super();
        this.state = {
            value: '',
            suggestions: []
        };
    }

    onChange = (_, { newValue }) => {
        const { id, onChange } = this.props;

        this.setState({
            value: newValue
        });
        this.props.handleSearchInput(newValue)
        //onChange(id, newValue);
    };

    onSuggestionsFetchRequested = ({ value }) => {
        this.setState({
            suggestions: getSuggestions(value)
        });
    };

    onSuggestionsClearRequested = () => {
        this.setState({
            suggestions: []
        });
    };

    componentWillMount(){
        AllproductModel.suggestionProduct().then((allProductName)=>{
            if(allProductName.data.hasOwnProperty('response'))
            {
                productNames = allProductName.data.response;
            }
        })
    }

    render() {
        const { id, placeholder } = this.props;
        const { value, suggestions } = this.state;
        const inputProps = {
            placeholder:'Search our products...',
            value,
            onChange: this.onChange
        };

        return (
            <Autosuggest
                id={id}
                suggestions={suggestions}
                onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                getSuggestionValue={getSuggestionValue}
                renderSuggestion={renderSuggestion}
                inputProps={inputProps}
                className="form-control"
            />
        );
    }
}


export default Searchinput;
