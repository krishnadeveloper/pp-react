import React from 'react';
import { NavLink } from "react-router-dom";

const Top = (props) => {
    return (
        <div className="top-header">
            <div className="container">
                <div className="pull-left">
                    <span>Brand Specialists Since 1980</span>
                </div>
                <div className="pull-right">
                    <ul className="list-inline">
                        {
                                props.isLogin
                                ? <li><NavLink to="/myorders">My Orders</NavLink></li>
                                : ''
                        }

                        {
                                props.isLogin
                                ? <li><a href="/index.php/auth/logout">Logout</a></li>
                                : <li><a href="/index.php/auth/login">Login</a></li>
                        }
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Top;