// API config class
import API from "./Api";
import Axios from "axios";

class Search extends API
{
    constructor()
    {
        super();
        this.endpoint ={
            search:super.getApiUrl()+'index.php/api?req='
        }
    }
    /**
     * Fetch products category wise
     * @param {*} keyword : Any string
     */
    findProduct(keyword)
    {
        return Axios.get(this.endpoint.search+encodeURIComponent(keyword))
    }

    /**
     * For search
     * @param {*} keyword : Any string
     */
    searchAll(keyword)
    {
        return Axios.get(this.endpoint.search+encodeURIComponent(keyword))
    }

}

export default new Search()
