import API from "./Api";
import Axios from "axios";


class HomeModel extends API {
    constructor(props) {
        super();
        this.home = {
            endpointNewProduct:super.getApiUrl()+'index.php/api?req=products/home/new',
            endpointPopularProduct:super.getApiUrl()+'index.php/api?req=products/home/popular'
        }
    }

    newProduct()
    {
        return Axios.get(this.home.endpointNewProduct)
    }

    popularProduct()
    {
        return Axios.get(this.home.endpointPopularProduct);
    }
    
}


export default new HomeModel();