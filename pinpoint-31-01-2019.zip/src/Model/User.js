import API from "./Api";
import Axios from "axios";

class User extends API
{
    constructor() {
        super();
        this.user = {
            endpoint:super.getApiUrl()+'index.php/myordersapi',
            userid:79
        }
    }

    findOrder(ordernum,reference,invoice,product,ordertime,status){
        return Axios.get(this.user.endpoint,{
            params:{
                ordernum:ordernum,
                designrefrence:reference,
                invoicenum:invoice,
                orderstatus:status,
                ordertime:ordertime,
                productid:product,
            }
        });
    }
    
}


export default new User();