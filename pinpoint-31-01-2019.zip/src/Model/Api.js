class Api{
    
    constructor(){
        this.config = {
            protocol:'http',
            port:'',
            prefix:'',
            host:'krishna.pinpoint.promo' //www.pinpoint.promo  - krishna.pinpoint.promo
        }
    }

    /**
     * @param {*} key : pass the key
     * @param {*} value : values of key
     */
    setConfig(key,value)
    {
        if(this.config.hasOwnProperty(key)){
            this.config[key] = value;
        }
    }

    getApiUrl()
    {
        var url = this.config.protocol+'://'+this.config.host;
        url = url+(this.config.port>0?':'+this.config.port+'/':'/');
        url = url+(this.config.prefix>0?this.config.prefix+'/':'');
        return url;
    }


    
}

export default Api;