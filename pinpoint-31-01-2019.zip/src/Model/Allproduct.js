import API from "./Api";
import axios from "axios";

class Allproduct extends API
{
    constructor(props) {
        super(props);
        this.allproduct = {
            endpoint:super.getApiUrl()+'index.php/productapi?req=products/all&',
            allproductnameEndpoint:super.getApiUrl()+'index.php/productapi?req2=products/name'
        }
    }
    
    search(params)
    {
        return axios.get(this.allproduct.endpoint+params);
    }

    suggestionProduct()
    {
        return axios.get(this.allproduct.allproductnameEndpoint);
    }
    
}

export default new Allproduct();