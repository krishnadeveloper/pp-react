import API from "./Api";
import Axios from "axios";

class Product extends API
{
    constructor()
    {
        
        super();
        this.endpoint = {
            productDetail:super.getApiUrl()+'index.php/db'
        }
    }


    find(reference)
    {
        return Axios.get(this.endpoint.productDetail,{
            params:{
                checkProduct:true,
                productId:reference
            }
        });
    }
}

export default new Product();