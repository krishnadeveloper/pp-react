const constantKey = {
    headerSearch:'_hdsr_',
    myorder:'_is_ord_',
    login:'_is_lg_',
    catIndex:'__p_cat_k_'
};

export default constantKey;